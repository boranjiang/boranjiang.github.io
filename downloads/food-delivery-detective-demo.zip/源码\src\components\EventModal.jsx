function getEventMood(event) {
  if (event.socialDeathDelta >= 70) {
    return { icon: "!!", text: "群聊空气突然安静" };
  }

  if (event.foodDelta >= 60) {
    return { icon: "🍜", text: "胃部发来胜利播报" };
  }

  if (event.clueDelta >= 35) {
    return { icon: "!", text: "线索雷达亮了" };
  }

  if (event.clueDelta < 0) {
    return { icon: "...", text: "破案进度小小后退" };
  }

  return { icon: "•ᴗ•", text: "这一步有点东西" };
}

function EventModal({ event, isFinalAction, onClose, onChoose }) {
  if (!event) {
    return null;
  }

  const mood = getEventMood(event);
  const hasChoices = event.choices?.length > 0;

  return (
    <div className="modal-backdrop" role="presentation" onClick={hasChoices ? undefined : onClose}>
      <section className="modal-panel event-panel" role="dialog" aria-modal="true" onClick={(clickEvent) => clickEvent.stopPropagation()}>
        <div className="event-mood" aria-hidden="true">
          <span>{mood.icon}</span>
          <small>{mood.text}</small>
        </div>
        <div className="modal-badge">{event.badge ?? "新线索"}</div>
        <h2>{event.name}</h2>
        <p className="event-text">{event.text}</p>

        {hasChoices && (
          <div className="event-options">
            {event.choices.map((choice) => (
              <button key={choice.id} className="event-option pressable" onClick={() => onChoose?.(choice)}>
                <span>{choice.label}</span>
                <strong>{choice.optionText}</strong>
                <small>
                  线索 {choice.clueDelta >= 0 ? "+" : ""}{choice.clueDelta} · 脸红 +{choice.socialDeathDelta} · 干饭 +{choice.foodDelta}
                </small>
              </button>
            ))}
          </div>
        )}

        {event.feedbackText && <p className="feedback-text">{event.feedbackText}</p>}

        {!hasChoices && (
          <>
            <div className="delta-row">
              <span className={event.clueDelta >= 0 ? "delta-plus" : "delta-minus"}>
                线索 {event.clueDelta >= 0 ? "+" : ""}{event.clueDelta}
              </span>
              <span className={event.socialDeathDelta > 0 ? "delta-warn" : "delta-plus"}>脸红 +{event.socialDeathDelta}</span>
              <span className="delta-plus">干饭 +{event.foodDelta}</span>
            </div>
            <button className="primary-button pressable" onClick={onClose}>
              {isFinalAction ? "查看我的追外卖人格" : "继续行动"}
            </button>
          </>
        )}
      </section>
    </div>
  );
}

export default EventModal;
