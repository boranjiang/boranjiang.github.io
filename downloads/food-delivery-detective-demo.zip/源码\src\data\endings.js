export const endings = {
  campusPatrol: {
    hidden: true,
    hiddenTitle: "隐藏剧情触发",
    hiddenHint: "校园巡逻队出现了，外卖进入离谱支线。",
    ending: "校园巡逻队结局",
    personality: "校园奇遇型",
    foodLocation: "操场边一条非常可疑的辣油路线尽头",
    endingText:
      "你顺着蓝色架子旁边的小票和食堂阿姨的线索一路追过去。\n\n最后在操场边发现：\n外卖袋没有被人拿走，\n它被小猫小狗当成了神秘宝藏，短暂加入了校园巡逻队。\n\n麻辣烫没能完整回来，\n但这段经历的离谱程度已经赢了。",
    profileText: "你不是在破案，你是在校园随机事件里抽到了隐藏剧情。",
    shareText: "我是校园奇遇型。\n我的外卖没被偷，它只是被校园巡逻队临时征用了。",
  },
  steamBunSupply: {
    hidden: true,
    hiddenTitle: "隐藏补给触发",
    hiddenHint: "保安大爷递来了馒头，饥饿值被温柔接住。",
    ending: "馒头补给结局",
    personality: "馒头补给型",
    foodLocation: "保安室抽屉旁边，外卖仍在路上",
    endingText:
      "你在保安室问了很多细节，眼神也越来越空。\n\n保安大爷看了看你，默默从抽屉里拿出一个馒头：\n“先垫垫，别饿坏了。”\n\n外卖还没找到，\n但你暂时活过来了。\n\n这不是破案胜利，\n这是校园人情味胜利。",
    profileText: "你查得不一定最快，但很容易被热心人投喂。",
    shareText: "我是馒头补给型。\n外卖还没回来，但保安大爷先把我救回来了。",
  },
  roommateTaste: {
    hidden: true,
    hiddenTitle: "隐藏审判触发",
    hiddenHint: "友情压力测试启动，室友和外卖都需要解释。",
    ending: "室友试吃结局",
    personality: "友情审判型",
    foodLocation: "室友手里，准确说是室友手里少了一口",
    endingText:
      "你顺着宿舍楼和群聊线索找过去，\n室友举着你的外卖，表情比你还复杂。\n\n他说：\n“我以为是我的，刚准备确认一下。”\n\n你看着少了一口的麻辣烫，\n开始认真评估这段友情还能打几分。",
    profileText: "你找回了外卖，也顺便触发了一次友情压力测试。",
    shareText: "我是友情审判型。\n外卖找到了，但室友和麻辣烫都需要重新评分。",
  },
  riderDetective: {
    hidden: true,
    hiddenTitle: "隐藏助攻触发",
    hiddenHint: "骑手递上关键证据，侦探位临时换人。",
    ending: "骑手侦探结局",
    personality: "骑手助攻型",
    foodLocation: "骑手照片里的保安亭蓝色架子",
    endingText:
      "你还在保安室和校门口之间整理线索，\n骑手已经把照片、时间、放置点全发来了。\n\n你突然发现：\n这案子不是你破的，\n是骑手替你破的。\n\n你负责紧张，\n骑手负责结案。",
    profileText: "你很努力，但这次 MVP 是骑手的聊天记录。",
    shareText: "我是骑手助攻型。\n我还在推理，骑手已经把答案发来了。",
  },
  meltdown: {
    ending: "暴躁开麦结局",
    personality: "暴躁开麦型",
    foodLocation: "群聊风暴中心，外卖暂时下落不明",
    endingText:
      "外卖找没找回先不说，\n宿舍群已经记住你了。\n\n你不是在破案，\n你是在全楼广播自己的饥饿。\n\n外卖可能只是拿错了，\n但你的冷静是真的丢了。",
    profileText: "你不是来找外卖的，你是来让全楼知道这件事的。",
    shareText: "我是暴躁开麦型。\n我的外卖还没找到，但我的群聊形象已经没了。",
  },
  foodFirst: {
    ending: "吃饭第一结局",
    personality: "吃饭第一型",
    foodLocation: "食堂窗口，外卖已经不重要了",
    endingText:
      "你放弃了继续追查，\n转身走进食堂。\n\n真相可以晚点来，\n饭不能晚点吃。\n\n在这一刻，\n你不是输了，\n你只是选择了活下去。",
    profileText: "你的人生哲学很稳定：真相可以等等，饭不能等等。",
    shareText: "我是吃饭第一型。\n外卖可以丢，饭点不能丢。",
  },
  drift: {
    ending: "外卖漂流结局",
    personality: "理性取证型",
    foodLocation: "校门口蓝色架子",
    endingText:
      "你没有急着骂人，\n而是先去确认源头。\n\n最后发现：\n不是被偷了，\n是外卖柜满了，它被放到了蓝色架子上。\n\n你的饭没有失踪，\n它只是短暂漂流。",
    profileText: "你知道有时候外卖不是被偷了，只是世界把它放错了位置。",
    shareText: "我是理性取证型。\n我不急着开麦，我先找源头。",
  },
  sourceVerifier: {
    ending: "源头复核结局",
    personality: "源头复核型",
    foodLocation: "保安亭旁边的蓝色架子",
    endingText:
      "你没有只听一边说法，\n也没有只盯着一段监控。\n\n骑手、保安室、时间线，\n三件事被你按顺序摆好。\n\n最后发现外卖确实没被偷，\n它只是被校园物流温柔地拐了个弯。",
    profileText: "你不迷信单条线索。你要的是前后能对上，细节能落地。",
    shareText: "我是源头复核型。\n我不是不相信人，我只是喜欢把线索对齐。",
  },
  politeHelper: {
    ending: "温柔求助结局",
    personality: "温柔求助型",
    foodLocation: "群聊线索指向的蓝色架子",
    endingText:
      "你没有开麦，\n也没有把群聊变成审讯现场。\n\n你只是很认真地问了一句，\n然后真的有人帮你补上了关键线索。\n\n外卖还没完全热回来，\n但你的校园人缘暂时保住了。",
    profileText: "你相信好好说话也能推进剧情。语气不炸，线索照样会来。",
    shareText: "我是温柔求助型。\n我用礼貌追外卖，用体面保住群聊。",
  },
  memeDetective: {
    ending: "整活破案结局",
    personality: "社交整活侦探型",
    foodLocation: "线索和梗一起指向的地点",
    endingText:
      "你把找外卖这件事，\n发成了一场小型群聊节目。\n\n有人接梗，有人补线索，\n事情变得不太严肃，\n但居然真的往前推进了。\n\n你可能不是最冷静的侦探，\n但你很会让线索自己走出来。",
    profileText: "你的调查方式有点热闹，但热闹里真的夹着线索。",
    shareText: "我是社交整活侦探型。\n我一边接梗，一边把外卖往回捞。",
  },
  detective: {
    ending: "冷静找回结局",
    personality: "冷静福尔摩斯型",
    foodLocation: "室友手里",
    endingText:
      "你没有误伤任何人，\n也成功找回了外卖。\n\n虽然麻辣烫已经有点凉了，\n但你的逻辑依然滚烫。\n\n你的外卖可以凉，\n但你的证据链不能断。",
    profileText: "你是那种外卖丢了也能先截图、看时间、问骑手的人。你不是不生气，你只是先把证据链补齐。",
    shareText: "我是冷静福尔摩斯型。\n外卖丢了我不慌，我先补证据链。",
  },
  halfDetective: {
    ending: "半吊子侦探结局",
    personality: "半吊子侦探型",
    foodLocation: "离真相很近，但还差最后一格",
    endingText:
      "你确实查到了一些东西，\n也确实离真相近了一点。\n\n问题是三步太短，\n你的推理还没来得及收口。\n\n这不是完全失败，\n更像是预告片播完了，正片还没开始。",
    profileText: "你已经摸到线索边缘了，只是还差一个把它钉死的动作。",
    shareText: "我是半吊子侦探型。\n我不是没查到，是差一点查完。",
  },
  lost: {
    ending: "校园迷路结局",
    personality: "校园迷路型",
    foodLocation: "校园某个未知角落",
    endingText:
      "你绕了半个校园，\n外卖没找到，\n自己更饿了。\n\n真相和午饭，\n总得丢一个。\n\n这次丢的是两个。",
    profileText: "你很努力，但努力的方向和外卖不在一个地图图层。",
    shareText: "我是校园迷路型。\n我不是没努力，我只是把自己也查丢了。",
  },
};
