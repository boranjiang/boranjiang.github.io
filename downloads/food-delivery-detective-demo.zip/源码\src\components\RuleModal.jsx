function RuleModal({ onClose }) {
  return (
    <div className="modal-backdrop" role="presentation" onClick={onClose}>
      <section className="modal-panel rule-panel" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
        <h2>玩法说明</h2>
        <p>滑动小人去不同地点。</p>
        <p>每一步都会改变你的线索值、脸红值和干饭值。</p>
        <p>三步之后，系统会判断你的追外卖人格。</p>
        <p className="modal-tip">
          线索值越高，越容易找回外卖；脸红值越高，越容易变成暴躁开麦型；干饭值越高，越容易放弃破案先吃饭。
        </p>
        <button className="primary-button pressable" onClick={onClose}>开始行动</button>
      </section>
    </div>
  );
}

export default RuleModal;
