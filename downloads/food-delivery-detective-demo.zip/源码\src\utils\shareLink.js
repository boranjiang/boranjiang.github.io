const LOCAL_RESULT_KEY = "takeaway:last-result:v1";
const SHARE_PARAM = "share";

function toBase64Url(text) {
  return window
    .btoa(unescape(encodeURIComponent(text)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function fromBase64Url(text) {
  const normalized = text.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  return decodeURIComponent(escape(window.atob(padded)));
}

export function createShareSnapshot(playerState) {
  return {
    version: 1,
    createdAt: Date.now(),
    ending: playerState.ending,
    personality: playerState.personality,
    foodLocation: playerState.foodLocation,
    hidden: playerState.hidden,
    hiddenTitle: playerState.hiddenTitle,
    hiddenHint: playerState.hiddenHint,
    endingText: playerState.endingText,
    profileText: playerState.profileText,
    shareText: playerState.shareText,
    comment: playerState.comment,
    clue: playerState.clue,
    socialDeath: playerState.socialDeath,
    food: playerState.food,
    visited: playerState.visited ?? [],
    actionHistory: playerState.actionHistory ?? [],
  };
}

export function saveLocalResult(playerState) {
  try {
    window.localStorage.setItem(LOCAL_RESULT_KEY, JSON.stringify(createShareSnapshot(playerState)));
  } catch {
    // Demo share still works through the URL even if local storage is unavailable.
  }
}

export function getLocalResult() {
  try {
    const raw = window.localStorage.getItem(LOCAL_RESULT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function encodeShareState(playerState) {
  return toBase64Url(JSON.stringify(createShareSnapshot(playerState)));
}

export function decodeShareState(value) {
  if (!value) {
    return null;
  }

  try {
    const parsed = JSON.parse(fromBase64Url(value));
    return parsed?.version === 1 ? parsed : null;
  } catch {
    return null;
  }
}

export function getIncomingShare() {
  if (typeof window === "undefined") {
    return null;
  }

  const params = new URLSearchParams(window.location.search);
  const queryShare = params.get(SHARE_PARAM);
  const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  const hashShare = hashParams.get(SHARE_PARAM);

  return decodeShareState(queryShare || hashShare);
}

export function buildShareUrl(playerState) {
  const url = new URL(window.location.href);
  const encodedShare = encodeShareState(playerState);

  url.searchParams.delete(SHARE_PARAM);
  url.hash = `${SHARE_PARAM}=${encodedShare}`;
  return url.toString();
}

// Future backend entry point:
// Replace buildShareUrl() with an API call that stores createShareSnapshot(playerState),
// returns a shareId, then opens /?shareId=xxx. The demo keeps all data in the URL.
