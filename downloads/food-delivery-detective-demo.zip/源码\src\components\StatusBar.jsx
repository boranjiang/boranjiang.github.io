function StatPill({ icon, label, value, tone, changed }) {
  return (
    <div className={`stat-pill ${tone} ${changed ? "stat-pop" : ""}`}>
      <span className="stat-label">
        <span className="stat-icon" aria-hidden="true">{icon}</span>
        {label}
      </span>
      <strong>{value}</strong>
    </div>
  );
}

function StatusBar({ playerState, lastDelta }) {
  return (
    <header className="status-bar">
      <StatPill icon="👟" label="行动" value={`${playerState.actions}/${playerState.maxActions}`} tone="action" changed={lastDelta?.actions} />
      <StatPill icon="🔍" label="线索值" value={playerState.clue} tone="clue" changed={lastDelta?.clueDelta} />
      <StatPill icon="🙈" label="脸红值" value={playerState.socialDeath} tone="social" changed={lastDelta?.socialDeathDelta} />
      <StatPill icon="🍚" label="干饭值" value={playerState.food} tone="food" changed={lastDelta?.foodDelta} />
    </header>
  );
}

export default StatusBar;
