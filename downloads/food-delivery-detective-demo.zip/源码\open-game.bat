@echo off
cd /d "%~dp0"

set GAME_URL=http://127.0.0.1:3060/

if not exist "node_modules\vite\bin\vite.js" (
  echo Vite dependency was not found.
  echo Open standalone.html directly as a fallback.
  pause
  exit /b 1
)

curl.exe -s --head --max-time 2 "%GAME_URL%" >nul 2>nul
if %errorlevel%==0 (
  echo Game server is already running.
  echo Opening %GAME_URL%
  start "" "%GAME_URL%"
  exit /b 0
)

echo Starting game at %GAME_URL%
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:3060/'"
node "node_modules\vite\bin\vite.js" --host 127.0.0.1 --port 3060 --strictPort --force

pause
