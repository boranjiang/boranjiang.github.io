import { endings } from "../data/endings.js";
import { enhanceEndingResult } from "./textEngine.js";

function hasChoice(playerState, choiceId) {
  return (playerState.actionHistory ?? []).some((action) => action.choiceId === choiceId);
}

function getLastChoiceId(playerState) {
  return (playerState.actionHistory ?? []).at(-1)?.choiceId;
}

export function calculateEnding(playerState) {
  const visited = playerState.visited;
  let result;

  if (
    hasChoice(playerState, "gate_shelf") &&
    hasChoice(playerState, "canteen_auntie") &&
    playerState.socialDeath === 0
  ) {
    result = endings.campusPatrol;
    return enhanceEndingResult(result);
  }

  if (
    hasChoice(playerState, "security_chat") &&
    getLastChoiceId(playerState) === "security_chat" &&
    !visited.includes("canteen") &&
    playerState.food >= 20 &&
    playerState.socialDeath < 70
  ) {
    result = endings.steamBunSupply;
    return enhanceEndingResult(result);
  }

  if (
    visited.includes("dorm") &&
    visited.includes("chat") &&
    (hasChoice(playerState, "dorm_roommates") || hasChoice(playerState, "dorm_quiet")) &&
    playerState.clue >= 60 &&
    playerState.socialDeath <= 25
  ) {
    result = endings.roommateTaste;
    return enhanceEndingResult(result);
  }

  if (
    hasChoice(playerState, "gate_rider") &&
    hasChoice(playerState, "security_monitor") &&
    playerState.socialDeath === 0
  ) {
    result = endings.riderDetective;
    return enhanceEndingResult(result);
  }

  if (playerState.socialDeath >= 70) {
    result = endings.meltdown;
    return enhanceEndingResult(result);
  }

  if (playerState.food >= 60) {
    result = endings.foodFirst;
    return enhanceEndingResult(result);
  }

  if (visited.includes("chat") && playerState.socialDeath >= 20 && playerState.clue >= 60) {
    result = endings.memeDetective;
    return enhanceEndingResult(result);
  }

  if (visited.includes("security") && visited.includes("gate") && playerState.clue >= 75) {
    result = endings.sourceVerifier;
    return enhanceEndingResult(result);
  }

  if (
    playerState.clue >= 70 &&
    visited.includes("security") &&
    visited.includes("dorm")
  ) {
    result = endings.detective;
    return enhanceEndingResult(result);
  }

  if (visited.includes("chat") && playerState.socialDeath <= 10 && playerState.clue >= 50) {
    result = endings.politeHelper;
    return enhanceEndingResult(result);
  }

  if (visited.includes("gate") && playerState.clue >= 50) {
    result = endings.drift;
    return enhanceEndingResult(result);
  }

  if (playerState.clue >= 50) {
    result = endings.halfDetective;
    return enhanceEndingResult(result);
  }

  result = endings.lost;
  return enhanceEndingResult(result);
}
