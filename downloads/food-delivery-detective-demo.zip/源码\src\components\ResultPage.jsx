import { getPersonalityNote } from "../data/personalityNotes.js";

function getPersonalityCharm(personality) {
  const charms = {
    校园奇遇型: { icon: "?", tag: "隐藏剧情" },
    馒头补给型: { icon: "馒", tag: "保安室回血" },
    友情审判型: { icon: "审", tag: "友情复盘" },
    骑手助攻型: { icon: "送", tag: "外援破案" },
    暴躁开麦型: { icon: "!!", tag: "音量拉满" },
    吃饭第一型: { icon: "🍜", tag: "先吃为敬" },
    理性取证型: { icon: "?", tag: "源头调查" },
    源头复核型: { icon: "OK", tag: "交叉验证" },
    温柔求助型: { icon: "~", tag: "体面求助" },
    社交整活侦探型: { icon: "哈", tag: "梗里找线索" },
    冷静福尔摩斯型: { icon: "!", tag: "证据链发光" },
    半吊子侦探型: { icon: "...", tag: "差点破案" },
    校园迷路型: { icon: "?", tag: "导航重启中" },
  };

  return charms[personality] ?? { icon: "•ᴗ•", tag: "路线很特别" };
}

function ResultPage({ playerState, onReplay, onBuddyReport }) {
  const note = getPersonalityNote(playerState.personality);
  const charm = getPersonalityCharm(playerState.personality);
  const isHiddenEnding = Boolean(playerState.hidden);

  return (
    <section className={`screen result-screen ${isHiddenEnding ? "hidden-ending-screen" : ""}`}>
      {isHiddenEnding && (
        <div className="hidden-ending-burst" aria-hidden="true">
          <span />
          <span />
          <span />
          <span />
          <span />
          <span />
        </div>
      )}
      <div className="result-ticket">
        {isHiddenEnding && (
          <div className="hidden-ending-ribbon" role="status">
            <strong>{playerState.hiddenTitle ?? "隐藏剧情触发"}</strong>
            <span>{playerState.hiddenHint ?? "你走出了一条不普通的追饭路线。"}</span>
          </div>
        )}
        <div className="personality-avatar" aria-hidden="true">
          <span>{charm.icon}</span>
          <small>{charm.tag}</small>
        </div>
        <span className="ticket-label">结局名</span>
        <h1>{playerState.ending}</h1>
        <div className="result-grid">
          <div>
            <span>你的追外卖人格</span>
            <strong>{playerState.personality}</strong>
          </div>
          <div>
            <span>外卖最终位置</span>
            <strong>{playerState.foodLocation}</strong>
          </div>
        </div>
        <div className="score-strip">
          <span>线索值 {playerState.clue}</span>
          <span>脸红值 {playerState.socialDeath}</span>
          <span>干饭值 {playerState.food}</span>
        </div>
        <p className="comment-text multiline">{playerState.endingText ?? playerState.comment}</p>
        <blockquote>{playerState.profileText ?? playerState.shareText}</blockquote>
        <p className="share-text multiline">{playerState.shareText}</p>
      </div>

      <section className="science-note personality-note">
        <h2>{note.title}</h2>
        <p className="multiline">{note.body}</p>
        {note.traits?.length > 0 && (
          <div className="personality-tags" aria-label="人格标签">
            {note.traits.map((trait) => (
              <span key={trait}>{trait}</span>
            ))}
          </div>
        )}
        {note.motto && <blockquote className="personality-motto">{note.motto}</blockquote>}
      </section>

      <div className="button-stack">
        <button className="secondary-button pressable" onClick={onReplay}>
          <span aria-hidden="true">↺</span>
          再追一次
        </button>
        <button className="primary-button pressable" onClick={onBuddyReport}>
          <span aria-hidden="true">＋</span>
          生成外卖搭子报告
        </button>
      </div>
    </section>
  );
}

export default ResultPage;
