import { useState } from "react";
import HomePage from "./components/HomePage.jsx";
import IntroScene from "./components/IntroScene.jsx";
import GameMap from "./components/GameMap.jsx";
import ResultPage from "./components/ResultPage.jsx";
import BuddyReportPage from "./components/BuddyReportPage.jsx";
import { calculateEnding } from "./utils/endingEngine.js";
import { getIncomingShare, getLocalResult, saveLocalResult } from "./utils/shareLink.js";

const initialPlayerState = {
  actions: 0,
  maxActions: 3,
  visited: [],
  actionHistory: [],
  clue: 0,
  socialDeath: 0,
  food: 0,
  currentLocation: "locker",
  ending: "",
  personality: "",
  foodLocation: "",
};

function App() {
  const [incomingShare] = useState(() => getIncomingShare());
  const [playerState, setPlayerState] = useState(() => {
    const savedResult = getLocalResult();
    return incomingShare && savedResult ? { ...initialPlayerState, ...savedResult } : initialPlayerState;
  });
  const [screen, setScreen] = useState(() => {
    const savedResult = getLocalResult();
    if (incomingShare && savedResult) {
      return "buddy";
    }

    if (incomingShare) {
      return "map";
    }

    return "home";
  });

  const startGame = () => {
    setPlayerState(initialPlayerState);
    setScreen("intro");
  };

  const enterMap = () => {
    setScreen("map");
  };

  const resetGame = () => {
    setPlayerState(initialPlayerState);
    setScreen("home");
  };

  const finishGame = (state) => {
    const result = calculateEnding(state);
    const finalState = { ...state, ...result };
    saveLocalResult(finalState);
    setPlayerState(finalState);
    setScreen(incomingShare ? "buddy" : "result");
  };

  return (
    <main className="app-shell">
      {screen === "home" && <HomePage onStart={startGame} incomingShare={incomingShare} />}
      {screen === "intro" && <IntroScene onContinue={enterMap} />}
      {screen === "map" && (
        <GameMap
          playerState={playerState}
          setPlayerState={setPlayerState}
          onFinish={finishGame}
        />
      )}
      {screen === "result" && (
        <ResultPage
          playerState={playerState}
          onReplay={resetGame}
          onBuddyReport={() => setScreen("buddy")}
        />
      )}
      {screen === "buddy" && (
        <BuddyReportPage
          playerState={playerState}
          sharedResult={incomingShare}
          onBack={() => setScreen("result")}
        />
      )}
    </main>
  );
}

export default App;
