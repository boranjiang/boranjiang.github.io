export const chatOptions = [
  {
    id: "chat_calm",
    label: "冷静询问",
    optionText: "请问有人拿错一份麻辣烫吗？12:04 送到 3 号柜，麻烦大家看一下～",
    resultText: "群里有人回复：\n“我刚刚好像看到有人拿着同款袋子往宿舍楼走了。”\n你获得了一条有效线索。",
    feedbackText: "线索值 +25：温柔发问，也能得到答案。",
    clueDelta: 25,
    socialDeathDelta: 0,
    foodDelta: 0,
  },
  {
    id: "chat_rage",
    label: "暴躁开麦",
    optionText: "谁偷我外卖了？？？赶紧还回来！！！",
    resultText: "宿舍群沉默了 5 秒。\n然后有人回复：\n“你先别急，会不会是拿错了……”\n你获得了一点线索，也失去了一点体面。",
    feedbackText: "脸红值 +70：宿舍群短暂安静了，世界也短暂安静了。",
    clueDelta: 30,
    socialDeathDelta: 70,
    foodDelta: 0,
  },
  {
    id: "chat_meme",
    label: "搞笑求助",
    optionText: "我的麻辣烫离家出走了，有人见过它吗？",
    resultText:
      "群里开始接梗。\n有人说：“它可能去追求自由了。”\n另一个人说：“我刚刚好像在外卖柜旁边见过同款袋子。”\n你获得了一点线索，但事情开始变得不太正经。",
    feedbackText: "线索值 +20，脸红值 +20：大家开始接梗，但线索也来了。",
    clueDelta: 20,
    socialDeathDelta: 20,
    foodDelta: 0,
  },
];

function ChatModal({ onChoose, onClose }) {
  return (
    <div className="modal-backdrop" role="presentation" onClick={onClose}>
      <section className="modal-panel chat-panel" role="dialog" aria-modal="true" onClick={(event) => event.stopPropagation()}>
        <div className="modal-badge chat-badge">宿舍群</div>
        <h2>你打开宿舍群，准备发消息。</h2>
        <p>你要怎么说？</p>
        <div className="chat-options">
          {chatOptions.map((option) => (
            <button key={option.id} className="chat-option pressable" onClick={() => onChoose(option)}>
              <span>{option.label}</span>
              <strong>{option.optionText}</strong>
              <small>
                线索 +{option.clueDelta} · 脸红 +{option.socialDeathDelta} · 干饭 +{option.foodDelta}
              </small>
            </button>
          ))}
        </div>
        <button className="text-button pressable" onClick={onClose}>先不发</button>
      </section>
    </div>
  );
}

export default ChatModal;
