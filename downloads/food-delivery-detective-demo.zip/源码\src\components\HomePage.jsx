import { useState } from "react";
import RuleModal from "./RuleModal.jsx";

function HomePage({ onStart, incomingShare }) {
  const [showRules, setShowRules] = useState(false);

  return (
    <section className="home-page screen">
      <div className="poster-shell">
        <div className="poster-spark spark-one" aria-hidden="true" />
        <div className="poster-spark spark-two" aria-hidden="true" />
        <div className="poster-spark spark-three" aria-hidden="true" />

        <header className="cover-hero">
          <div className="cover-bag" aria-hidden="true">
            <span className="cover-bag-knot" />
            <span className="cover-bag-box" />
            <span className="cover-bag-face" />
          </div>
          <div className="cover-title-group">
            <p className="cover-kicker">校园轻解谜 · 外卖追踪事件</p>
            <h1>谁拿了我的外卖？</h1>
          </div>
          <p className="subtitle cover-subtitle">三步找回黄焖鸡，或者三步失去群聊形象。</p>
        </header>

        <div className="poster-tags" aria-hidden="true">
          <span>校园轻解谜</span>
          <span>社交分享</span>
        </div>

        {incomingShare && (
          <div className="share-invite-card">
            <strong>{incomingShare.personality || "神秘追饭人"} 发来搭子邀请</strong>
            <span>先完成你的三步追饭，系统会自动生成你们的相似度报告。</span>
          </div>
        )}

        <div className="cover-board">
          <aside className="clue-note" aria-label="线索贴纸">
            <h2>线索贴纸</h2>
            <span className="clue-pin" aria-hidden="true" />
            <div className="clue-item">
              <span className="clue-icon shelf" aria-hidden="true" />
              <span>蓝色架子</span>
            </div>
            <div className="clue-item">
              <span className="clue-icon hoodie" aria-hidden="true" />
              <span>蓝衣人</span>
            </div>
            <div className="clue-item">
              <span className="clue-icon phone" aria-hidden="true" />
              <span>骑手照片</span>
            </div>
          </aside>

          <div className="cover-map-preview" aria-hidden="true">
            <div className="preview-route route-a" />
            <div className="preview-route route-b" />
            <span className="map-pin pin-locker">1</span>
            <span className="map-pin pin-security">2</span>
            <span className="map-pin pin-dorm">3</span>
            <span className="preview-label label-locker">外卖柜</span>
            <span className="preview-label label-security">保安室</span>
            <span className="preview-label label-dorm">宿舍楼</span>
            <span className="preview-chat">99+</span>
          </div>
        </div>

        <div className="quick-actions" aria-hidden="true">
          <span>先查证据？</span>
          <span>先发群？</span>
          <span>先吃饭？</span>
        </div>

        <div className="how-play-panel">
          <h2>怎么玩</h2>
          <div className="play-steps">
            <span><b>1</b> 看线索</span>
            <span><b>2</b> 选路线</span>
            <span><b>3</b> 解结局</span>
          </div>
        </div>

        <div className="button-stack">
          <button className="primary-button pressable" onClick={onStart}>
            <span aria-hidden="true">▶</span>
            开始追外卖
          </button>
          <button className="secondary-button pressable" onClick={() => setShowRules(true)}>
            <span aria-hidden="true">?</span>
            先看玩法
          </button>
        </div>

        <p className="home-footer-tip">外卖可能会丢，群聊形象不一定保住。</p>
      </div>
      {showRules && <RuleModal onClose={() => setShowRules(false)} />}
    </section>
  );
}

export default HomePage;
