import { useEffect, useRef } from "react";

function IntroScene({ onContinue }) {
  const hasContinued = useRef(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      handleContinue();
    }, 5000);

    return () => window.clearTimeout(timer);
  }, []);

  const handleContinue = () => {
    if (hasContinued.current) {
      return;
    }

    hasContinued.current = true;
    onContinue();
  };

  return (
    <section className="screen intro-scene" onClick={handleContinue}>
      <div className="intro-card" role="button" tabIndex={0} onKeyDown={(event) => event.key === "Enter" && handleContinue()}>
        <div className="intro-sky" aria-hidden="true">
          <span className="intro-cloud cloud-one" />
          <span className="intro-cloud cloud-two" />
          <span className="intro-spark spark-a" />
          <span className="intro-spark spark-b" />
        </div>

        <div className="intro-locker" aria-hidden="true">
          <span className="intro-locker-top">24h</span>
          <span className="intro-locker-door" />
          <span className="intro-empty-slot" />
        </div>

        <div className="intro-player" aria-hidden="true">
          <span className="intro-bubble">
            我的外卖丢了，<br />
            我该怎么办！
          </span>
          <span className="intro-player-head" />
          <span className="intro-player-body" />
          <span className="intro-player-bag" />
          <span className="intro-player-foot foot-left" />
          <span className="intro-player-foot foot-right" />
          <span className="intro-player-shadow" />
        </div>

        <div className="intro-copy">
          <strong>外卖柜里空空如也。</strong>
          <span>三步之内，去宿舍楼、保安室、食堂、校门口或群聊里找线索。</span>
        </div>

        <button className="intro-continue pressable" type="button" onClick={handleContinue}>
          点一下开始调查
        </button>
        <p className="intro-auto-tip">5 秒后自动进入</p>
      </div>
    </section>
  );
}

export default IntroScene;
