import { appendBuddyTail } from "../utils/textEngine.js";

const defaultReport = {
  name: "临时追饭搭子",
  comment: "你们的路线不一定专业，但情绪绝对真实。",
  returnRate: "60%",
  socialDeathRate: "40%",
  hungerSpeed: "50%",
  shareText: "我和TA的外卖搭子组合是「临时追饭搭子」。",
};

export const buddyReports = {
  "冷静福尔摩斯型__冷静福尔摩斯型": {
    name: "双侦探组合",
    comment: "你们查得很准，证据链也很完整。\n唯一的问题是：等你们查清楚的时候，饭已经凉透了。",
    returnRate: "96%",
    socialDeathRate: "3%",
    hungerSpeed: "35%",
  },
  "冷静福尔摩斯型__暴躁开麦型": {
    name: "证据链与大喇叭",
    comment: "你负责把事情查清楚，TA负责把事情闹大。\n外卖大概率能回来，但宿舍群也大概率回不去了。",
    returnRate: "91%",
    socialDeathRate: "76%",
    hungerSpeed: "42%",
  },
  "冷静福尔摩斯型__吃饭第一型": {
    name: "证据和米饭都要",
    comment: "一个负责查监控，一个负责提醒：“要不先吃点？”\n你们的关系很健康，因为有人负责理智，有人负责活着。",
    returnRate: "78%",
    socialDeathRate: "8%",
    hungerSpeed: "86%",
  },
  "冷静福尔摩斯型__理性取证型": {
    name: "校园秩序维护组",
    comment: "外卖可以凉，证据链不能断。\n你们是最有可能不误伤任何人的组合。",
    returnRate: "96%",
    socialDeathRate: "3%",
    hungerSpeed: "38%",
  },
  "冷静福尔摩斯型__校园迷路型": {
    name: "导航失灵但脑子在线",
    comment: "一个负责走错路，一个负责把路线纠回来。\n虽然过程混乱，但还有救。",
    returnRate: "72%",
    socialDeathRate: "18%",
    hungerSpeed: "46%",
  },
  "暴躁开麦型__暴躁开麦型": {
    name: "宿舍群核弹",
    comment: "外卖还没找到，群聊已经爆炸。\n你们不一定能追回饭，但一定能把事情闹到全楼皆知。",
    returnRate: "58%",
    socialDeathRate: "99%",
    hungerSpeed: "55%",
  },
  "暴躁开麦型__吃饭第一型": {
    name: "一边开麦一边干饭",
    comment: "一个负责在群里输出情绪，一个负责去食堂稳定血糖。\n你们解决问题的方式很吵，但不会饿着。",
    returnRate: "49%",
    socialDeathRate: "82%",
    hungerSpeed: "90%",
  },
  "暴躁开麦型__理性取证型": {
    name: "刹车和油门",
    comment: "TA刚想开麦，你已经开始查源头。\n你们一个踩油门，一个踩刹车，车很晃，但还能往前走。",
    returnRate: "84%",
    socialDeathRate: "61%",
    hungerSpeed: "52%",
  },
  "暴躁开麦型__校园迷路型": {
    name: "嚷嚷但走反了",
    comment: "你们声音很大，方向很迷。\n外卖可能没听见，但全楼都听见了。",
    returnRate: "40%",
    socialDeathRate: "88%",
    hungerSpeed: "50%",
  },
  "吃饭第一型__吃饭第一型": {
    name: "真相不如干饭",
    comment: "别人还在查监控，你们已经在食堂点第二份了。\n你们可能找不回外卖，但一定不会饿着自己。",
    returnRate: "22%",
    socialDeathRate: "5%",
    hungerSpeed: "99%",
  },
  "吃饭第一型__理性取证型": {
    name: "饭要吃证据也要留",
    comment: "一个说先吃饭，一个说先确认骑手。\n最后你们决定：边吃边查，效率意外还不错。",
    returnRate: "70%",
    socialDeathRate: "6%",
    hungerSpeed: "88%",
  },
  "吃饭第一型__校园迷路型": {
    name: "食堂导航二人组",
    comment: "你们本来想找外卖，结果一起走到了食堂。\n方向错了，但心情对了。",
    returnRate: "34%",
    socialDeathRate: "10%",
    hungerSpeed: "94%",
  },
  "理性取证型__理性取证型": {
    name: "源头调查组",
    comment: "你们不会先骂人，也不会先乱跑。\n从骑手到柜号再到放置点，查得像一份小型报告。",
    returnRate: "95%",
    socialDeathRate: "2%",
    hungerSpeed: "40%",
  },
  "理性取证型__校园迷路型": {
    name: "一个查源头一个跑偏",
    comment: "一个知道要问骑手，一个总能走到奇怪的地方。\n幸好你们至少没有一上来就开骂。",
    returnRate: "69%",
    socialDeathRate: "15%",
    hungerSpeed: "48%",
  },
  "校园迷路型__校园迷路型": {
    name: "校园迷航小队",
    comment: "你们都很努力，也都不太认路。\n外卖还没找到，但校园熟悉了不少。",
    returnRate: "18%",
    socialDeathRate: "12%",
    hungerSpeed: "62%",
  },
};

export function getBuddyReport(playerType, friendType) {
  const directKey = `${playerType}__${friendType}`;
  const reverseKey = `${friendType}__${playerType}`;
  const report = buddyReports[directKey] ?? buddyReports[reverseKey] ?? defaultReport;

  return appendBuddyTail({
    ...report,
    shareText: report.shareText ?? `我和TA的外卖搭子组合是「${report.name}」。`,
  });
}
