import { useEffect, useRef, useState } from "react";
import { chatLocation, locations } from "../data/locations.js";
import StatusBar from "./StatusBar.jsx";
import EventModal from "./EventModal.jsx";
import ChatModal from "./ChatModal.jsx";
import { getContextualChatResult, getContextualLocationEvent } from "../utils/textEngine.js";

const MOVE_DURATION = 520;
const DROP_DISTANCE = 13;
const LOCATION_HITBOXES = {
  dorm: { width: 34, height: 15, offsetY: 1 },
  security: { width: 25, height: 19, offsetY: 1 },
  canteen: { width: 27, height: 23, offsetY: -1 },
  gate: { width: 28, height: 12, offsetY: 0 },
  locker: { width: 30, height: 20, offsetY: 0 },
};

function clampStat(value) {
  return Math.max(0, value);
}

function getPosition(locationId) {
  if (locationId === "chat") {
    return chatLocation;
  }

  return locations.find((location) => location.id === locationId) ?? locations[0];
}

function getMoveDirection(fromLocationId, toLocationId) {
  const from = getPosition(fromLocationId);
  const to = getPosition(toLocationId);
  const dx = to.x - from.x;
  const dy = to.y - from.y;

  if (Math.abs(dx) > Math.abs(dy)) {
    return dx > 0 ? "right" : "left";
  }

  return dy > 0 ? "down" : "up";
}

function getMapHint(playerState, isDragging) {
  const remain = playerState.maxActions - playerState.actions;

  if (isDragging) {
    return "拖到地点附近松手，就会触发调查。";
  }

  if (playerState.actions === 0) {
    return "拖住小人，把他带到你想调查的地点。";
  }

  if (remain === 1) {
    return "最后一步了，拖稳一点，别让外卖和冷静一起消失。";
  }

  return `还剩 ${remain} 步，想清楚再跑。`;
}

function getLocationName(locationId) {
  if (locationId === "chat") {
    return "群聊";
  }

  return locations.find((location) => location.id === locationId)?.name ?? "外卖柜";
}

function getRouteSummary(playerState, hoverTargetId, isDragging) {
  const currentName = getLocationName(playerState.currentLocation);
  const remain = Math.max(0, playerState.maxActions - playerState.actions);
  const visitedRoute = ["外卖柜", ...(playerState.visited ?? []).map(getLocationName)];
  const routeText = visitedRoute.length > 1 ? visitedRoute.join(" → ") : `当前位置：${currentName}`;

  if (isDragging && hoverTargetId) {
    return `正拖向：${getLocationName(hoverTargetId)}｜松手就去调查`;
  }

  if (isDragging) {
    return `拖动中｜当前位置：${currentName}`;
  }

  return `${routeText}｜还剩 ${remain} 步`;
}

function getRouteSteps(playerState) {
  const visited = playerState.visited ?? [];
  return ["locker", ...visited].map((locationId, index) => ({
    id: `${locationId}-${index}`,
    locationId,
    name: getLocationName(locationId),
    label: index === 0 ? "起点" : `第 ${index} 步`,
  }));
}

function getRouteTrailPoints(routeSteps) {
  return routeSteps.map((step) => {
    const position = getPosition(step.locationId);
    return {
      ...step,
      x: position.x,
      y: position.y,
    };
  });
}

function getPlayerMood({ isDragging, hoverTargetId, playerState }) {
  if (isDragging && hoverTargetId) {
    return "松手！";
  }

  if (isDragging) {
    return "冲呀";
  }

  if (playerState.actions === 0) {
    return "拖我";
  }

  if (playerState.food >= 60) {
    return "想吃";
  }

  if (playerState.socialDeath >= 70) {
    return "尴尬";
  }

  if (playerState.clue >= 70) {
    return "稳了";
  }

  return "继续";
}

function getActionFeedbackText(nextState, clueDelta, socialDeathDelta, foodDelta) {
  if (socialDeathDelta >= 70) {
    return "脸红值 +70：宿舍群短暂安静了，世界也短暂安静了。";
  }

  if (foodDelta >= 60) {
    return "干饭值 +60：你的理智回来了，但破案进度没了。";
  }

  if (nextState.clue >= 70 && nextState.socialDeath < 70 && nextState.food < 60) {
    return "线索已经够了，接下来别把事情搞砸。";
  }

  if (nextState.visited.includes("gate") && nextState.clue >= 50) {
    return "源头线索成立，外卖可能只是放错了。";
  }

  if (nextState.actions === 2 && nextState.clue < 30) {
    return "你已经跑了两步，但真相还很远。";
  }

  if (clueDelta > 0 || foodDelta > 0 || socialDeathDelta > 0) {
    const parts = [];
    if (clueDelta) parts.push(`线索值 ${clueDelta > 0 ? "+" : ""}${clueDelta}`);
    if (socialDeathDelta) parts.push(`脸红值 +${socialDeathDelta}`);
    if (foodDelta) parts.push(`干饭值 +${foodDelta}`);
    return `${parts.join("，")}：每一步都算数。`;
  }

  return "你还有下一步机会。";
}

function getFinalTransitionText(nextState) {
  if (nextState.socialDeath >= 70) {
    return "群聊还在沉默，系统正在计算你的脸红程度。";
  }

  if (nextState.food >= 60) {
    return "你离真相不一定近，但离饭很近。";
  }

  if (nextState.clue >= 70) {
    return "线索拼起来了，真相快露面了。";
  }

  if (nextState.clue < 30) {
    return "你跑得很努力，但线索没有跟上。";
  }

  return "三步结束。外卖、冷静和体面，至少有一个会留下。";
}

function toMapPercent(pointerEvent, mapElement) {
  const rect = mapElement.getBoundingClientRect();
  const x = ((pointerEvent.clientX - rect.left) / rect.width) * 100;
  const y = ((pointerEvent.clientY - rect.top) / rect.height) * 100;

  return {
    x: Math.max(6, Math.min(94, x)),
    y: Math.max(7, Math.min(93, y)),
  };
}

function getNearestLocation(position) {
  if (!position) {
    return null;
  }

  let nearest = null;
  let nearestDistance = Infinity;

  for (const location of locations) {
    if (location.id === "locker") {
      continue;
    }

    const hitbox = LOCATION_HITBOXES[location.id];
    const centerX = location.x + (hitbox?.offsetX ?? 0);
    const centerY = location.y + (hitbox?.offsetY ?? 0);
    const dx = centerX - position.x;
    const dy = centerY - position.y;
    const isInsideHitbox =
      hitbox &&
      Math.abs(dx) <= hitbox.width / 2 &&
      Math.abs(dy) <= hitbox.height / 2;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (isInsideHitbox) {
      return location;
    }

    if (distance < nearestDistance) {
      nearest = location;
      nearestDistance = distance;
    }
  }

  return nearestDistance <= DROP_DISTANCE ? nearest : null;
}

function GameMap({ playerState, setPlayerState, onFinish }) {
  const [activeEvent, setActiveEvent] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const [lastDelta, setLastDelta] = useState(null);
  const [dragPosition, setDragPosition] = useState(null);
  const [hoverTargetId, setHoverTargetId] = useState("");
  const [motion, setMotion] = useState({
    isMoving: false,
    direction: "down",
    landingKey: 0,
  });
  const mapRef = useRef(null);
  const moveTimer = useRef(null);
  const currentPosition = getPosition(playerState.currentLocation);
  const displayPosition = dragPosition ?? currentPosition;
  const isInteractionBlocked = playerState.actions >= playerState.maxActions || activeEvent || showChat;
  const canStartDrag = !isInteractionBlocked && !motion.isMoving;
  const routeSteps = getRouteSteps(playerState);
  const routeTrailPoints = getRouteTrailPoints(routeSteps);
  const routePolyline = routeTrailPoints.map((point) => `${point.x},${point.y}`).join(" ");
  const playerMood = getPlayerMood({
    isDragging: Boolean(dragPosition),
    hoverTargetId,
    playerState,
  });

  useEffect(() => {
    return () => {
      if (moveTimer.current) {
        window.clearTimeout(moveTimer.current);
      }
    };
  }, []);

  const showRepeatEvent = (locationId, locationName) => {
    const location = locations.find((item) => item.id === locationId);
    setMotion((currentMotion) => ({
      ...currentMotion,
      isMoving: false,
      landingKey: Date.now(),
    }));
    setActiveEvent({
      badge: "已查过",
      name: locationName,
      text: location?.repeatText ?? "这里已经查过了，再查一遍只会让饭更凉。",
      feedbackText: "这里已经查过了，再查一遍只会让饭更凉。",
      clueDelta: 0,
      socialDeathDelta: 0,
      foodDelta: 0,
      nextState: playerState,
    });
  };

  const showLocationChoices = (location) => {
    if (isInteractionBlocked) {
      return;
    }

    if (playerState.visited.includes(location.id)) {
      showRepeatEvent(location.id, location.name);
      return;
    }

    const eventLocation = getContextualLocationEvent(location, playerState);
    const direction = getMoveDirection(playerState.currentLocation, location.id);

    setPlayerState((currentState) => ({
      ...currentState,
      currentLocation: location.id,
    }));
    setMotion((currentMotion) => ({
      isMoving: true,
      direction,
      landingKey: currentMotion.landingKey,
    }));

    if (moveTimer.current) {
      window.clearTimeout(moveTimer.current);
    }

    moveTimer.current = window.setTimeout(() => {
      setMotion({ isMoving: false, direction, landingKey: Date.now() });
      setActiveEvent({
        badge: "现场选择",
        name: location.name,
        text: eventLocation.event,
        choices: eventLocation.choices,
        locationId: location.id,
        locationName: location.name,
        clueDelta: 0,
        socialDeathDelta: 0,
        foodDelta: 0,
      });
    }, MOVE_DURATION);
  };

  const commitLocationChoice = (choice) => {
    if (!activeEvent?.locationId || !choice) {
      return;
    }

    const locationId = activeEvent.locationId;
    const nextState = {
      ...playerState,
      actions: playerState.actions + 1,
      currentLocation: locationId,
      visited: [...playerState.visited, locationId],
      actionHistory: [
        ...(playerState.actionHistory ?? []),
        {
          type: "location",
          locationId,
          choiceId: choice.id,
          label: choice.label,
        },
      ],
      clue: clampStat(playerState.clue + choice.clueDelta),
      socialDeath: clampStat(playerState.socialDeath + choice.socialDeathDelta),
      food: clampStat(playerState.food + choice.foodDelta),
    };
    const nextEvent = {
      badge: "行动结果",
      name: choice.label,
      text: choice.resultText,
      clueDelta: choice.clueDelta,
      socialDeathDelta: choice.socialDeathDelta,
      foodDelta: choice.foodDelta,
      feedbackText:
        playerState.actions + 1 >= playerState.maxActions
          ? getFinalTransitionText(nextState)
          : choice.feedbackText ?? getActionFeedbackText(nextState, choice.clueDelta, choice.socialDeathDelta, choice.foodDelta),
      nextState,
    };

    setLastDelta({
      actions: 1,
      clueDelta: choice.clueDelta,
      socialDeathDelta: choice.socialDeathDelta,
      foodDelta: choice.foodDelta,
    });
    setPlayerState(nextState);
    setActiveEvent(nextEvent);
  };

  const handleDropAtLocation = (location) => {
    showLocationChoices(location);
  };

  const handlePointerDown = (event) => {
    if (!canStartDrag || !mapRef.current) {
      return;
    }

    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    const nextPosition = toMapPercent(event, mapRef.current);
    const nearest = getNearestLocation(nextPosition);

    setDragPosition(nextPosition);
    setHoverTargetId(nearest?.id ?? "");
    setMotion((currentMotion) => ({
      ...currentMotion,
      isMoving: true,
      direction: getMoveDirection(playerState.currentLocation, nearest?.id ?? playerState.currentLocation),
    }));
  };

  const handlePointerMove = (event) => {
    if (!dragPosition || !mapRef.current) {
      return;
    }

    event.preventDefault();
    const nextPosition = toMapPercent(event, mapRef.current);
    const nearest = getNearestLocation(nextPosition);

    setDragPosition(nextPosition);
    setHoverTargetId(nearest?.id ?? "");
    if (nearest) {
      setMotion((currentMotion) => ({
        ...currentMotion,
        direction: getMoveDirection(playerState.currentLocation, nearest.id),
      }));
    }
  };

  const handlePointerUp = (event) => {
    if (!dragPosition) {
      setMotion((currentMotion) => ({
        ...currentMotion,
        isMoving: false,
      }));
      return;
    }

    event.preventDefault();
    const droppedLocation = getNearestLocation(dragPosition);

    setDragPosition(null);
    setHoverTargetId("");

    if (droppedLocation) {
      handleDropAtLocation(droppedLocation);
      return;
    }

    setMotion((currentMotion) => ({
      ...currentMotion,
      isMoving: false,
      landingKey: Date.now(),
    }));
  };

  const handleChatChoice = (option) => {
    if (motion.isMoving || playerState.actions >= playerState.maxActions) {
      return;
    }

    const chatResult = getContextualChatResult(option);
    const direction = getMoveDirection(playerState.currentLocation, "chat");
    const nextState = {
      ...playerState,
      actions: playerState.actions + 1,
      currentLocation: "chat",
      visited: [...playerState.visited, "chat"],
      actionHistory: [
        ...(playerState.actionHistory ?? []),
        {
          type: "chat",
          locationId: "chat",
          choiceId: option.id,
          label: option.label,
        },
      ],
      clue: clampStat(playerState.clue + chatResult.clueDelta),
      socialDeath: clampStat(playerState.socialDeath + chatResult.socialDeathDelta),
      food: clampStat(playerState.food + chatResult.foodDelta),
    };

    setLastDelta({
      actions: 1,
      clueDelta: chatResult.clueDelta,
      socialDeathDelta: chatResult.socialDeathDelta,
      foodDelta: chatResult.foodDelta,
    });
    setPlayerState(nextState);
    setShowChat(false);
    setMotion((currentMotion) => ({
      isMoving: true,
      direction,
      landingKey: currentMotion.landingKey,
    }));

    if (moveTimer.current) {
      window.clearTimeout(moveTimer.current);
    }

    moveTimer.current = window.setTimeout(() => {
      setMotion({ isMoving: false, direction, landingKey: Date.now() });
      setActiveEvent({
        badge: "群聊回复",
        name: chatResult.label,
        text: chatResult.resultText,
        feedbackText:
          nextState.actions >= nextState.maxActions
            ? getFinalTransitionText(nextState)
            : chatResult.feedbackText,
        clueDelta: chatResult.clueDelta,
        socialDeathDelta: chatResult.socialDeathDelta,
        foodDelta: chatResult.foodDelta,
        nextState,
      });
    }, MOVE_DURATION);
  };

  const closeEvent = () => {
    const nextState = activeEvent.nextState;
    setActiveEvent(null);
    if (nextState.actions >= nextState.maxActions) {
      onFinish(nextState);
    }
  };

  const openChat = () => {
    if (playerState.actions >= playerState.maxActions || activeEvent || motion.isMoving) {
      return;
    }

    if (playerState.visited.includes("chat")) {
      setMotion((currentMotion) => ({
        ...currentMotion,
        isMoving: false,
        landingKey: Date.now(),
      }));
      setActiveEvent({
        badge: "已发过",
        name: "宿舍群",
        text: "群已经发过一次了，再发就像在开连续剧。",
        feedbackText: "群已经发过一次了，再发就像在开连续剧。",
        clueDelta: 0,
        socialDeathDelta: 0,
        foodDelta: 0,
        nextState: playerState,
      });
      return;
    }

    setShowChat(true);
  };

  return (
    <section className="screen map-screen">
      <StatusBar playerState={playerState} lastDelta={lastDelta} />
      <div className="map-title-row">
        <h1>校园追饭图</h1>
        <span>{getMapHint(playerState, Boolean(dragPosition))}</span>
      </div>
      <div className="route-log">
        <span>{getRouteSummary(playerState, hoverTargetId, Boolean(dragPosition))}</span>
        <div className="route-steps" aria-label="已行动路线">
          {routeSteps.map((step, index) => (
            <div
              key={step.id}
              className={`route-step ${index === routeSteps.length - 1 ? "is-latest" : ""}`}
            >
              <small>{step.label}</small>
              <strong>{step.name}</strong>
            </div>
          ))}
        </div>
      </div>
      <div ref={mapRef} className={`campus-map ${dragPosition ? "is-dragging" : ""}`}>
        <div className="map-backdrop" aria-hidden="true" />
        <div className="map-path path-vertical" />
        <div className="map-path path-horizontal" />
        <div className="map-path path-diagonal-one" />
        <div className="map-path path-diagonal-two" />
        {routeTrailPoints.length > 1 && (
          <svg className="route-trail" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            <polyline className="route-trail-shadow" points={routePolyline} />
            <polyline className="route-trail-line" points={routePolyline} />
            {routeTrailPoints.map((point, index) => (
              <g key={point.id}>
                <circle
                  className={`route-trail-dot ${index === routeTrailPoints.length - 1 ? "is-latest" : ""}`}
                  cx={point.x}
                  cy={point.y}
                  r={index === 0 ? 1.45 : 1.85}
                />
                {index > 0 && (
                  <text className="route-trail-number" x={point.x} y={point.y + 0.25}>
                    {index}
                  </text>
                )}
              </g>
            ))}
          </svg>
        )}
        <div className={`swipe-hint hint-${motion.direction} ${dragPosition ? "is-active" : ""}`} aria-hidden="true">
          {motion.direction === "up" && "↑"}
          {motion.direction === "right" && "→"}
          {motion.direction === "left" && "←"}
          {motion.direction === "down" && "↓"}
        </div>

        {locations.map((location) => (
          <div
            key={location.id}
            className={`map-location ${location.id} ${playerState.currentLocation === location.id ? "current" : ""} ${
              playerState.visited.includes(location.id) ? "visited" : ""
            } ${
              hoverTargetId === location.id ? "drop-target" : ""
            }`}
            style={{ left: `${location.x}%`, top: `${location.y}%` }}
          >
            <span className="location-icon" aria-hidden="true">
              {location.id === "locker" && "▣"}
              {location.id === "security" && "!"}
              {location.id === "dorm" && "⌂"}
              {location.id === "gate" && "⌁"}
              {location.id === "canteen" && "◒"}
            </span>
            <span>{location.name}</span>
          </div>
        ))}

        <button
          className="chat-bubble pressable"
          style={{ left: `${chatLocation.x}%`, top: `${chatLocation.y}%` }}
          onClick={openChat}
          disabled={playerState.actions >= playerState.maxActions || motion.isMoving}
        >
          群聊
        </button>

        {motion.landingKey > 0 && !motion.isMoving && (
          <div
            key={motion.landingKey}
            className="landing-burst"
            style={{
              left: `${currentPosition.x}%`,
              top: `${currentPosition.y}%`,
            }}
            aria-hidden="true"
          />
        )}
        <div
          className={`player-token ${motion.isMoving ? "is-moving" : ""} ${dragPosition ? "is-dragging" : ""} move-${
            motion.direction
          } ${playerState.currentLocation === "chat" ? "at-chat" : ""}`}
          style={{
            left: `${displayPosition.x}%`,
            top: `${displayPosition.y}%`,
          }}
          role="button"
          tabIndex={0}
          aria-label="拖动小人到地点调查"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
        >
          <span className="player-mood" aria-hidden="true">{playerMood}</span>
          <span className="runner-dust dust-one" aria-hidden="true" />
          <span className="runner-dust dust-two" aria-hidden="true" />
          <span className="runner-dust dust-three" aria-hidden="true" />
          <span className="player-leg leg-back" aria-hidden="true" />
          <span className="player-leg leg-front" aria-hidden="true" />
          <span className="player-arm arm-back" aria-hidden="true" />
          <span className="player-body" aria-hidden="true">
            <span className="player-backpack" aria-hidden="true" />
          </span>
          <span className="player-arm arm-front" aria-hidden="true" />
          <span className="player-head" aria-hidden="true" />
          <span className="player-shadow" aria-hidden="true" />
        </div>
      </div>
      {activeEvent && (
        <EventModal
          event={activeEvent}
          isFinalAction={activeEvent.nextState?.actions >= playerState.maxActions}
          onClose={closeEvent}
          onChoose={commitLocationChoice}
        />
      )}
      {showChat && <ChatModal onChoose={handleChatChoice} onClose={() => setShowChat(false)} />}
    </section>
  );
}

export default GameMap;
