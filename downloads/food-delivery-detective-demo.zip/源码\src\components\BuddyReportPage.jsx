import { useMemo, useState } from "react";
import { getBuddyReport } from "../data/buddyReports.js";
import { personalityProfiles } from "../data/personalities.js";
import { calculateSimilarity } from "../utils/similarity.js";
import { buildShareUrl } from "../utils/shareLink.js";

function getRouteOverlap(playerState, friendState) {
  const playerVisited = new Set(playerState.visited ?? []);
  const friendVisited = new Set(friendState?.visited ?? []);
  return [...playerVisited].filter((item) => friendVisited.has(item)).length;
}

function getMatchTone(similarity) {
  if (similarity >= 85) return "你们像是同一个外卖柜里分裂出来的两套破案系统。";
  if (similarity >= 68) return "你们节奏挺接近，一个眼神就知道下一步该去哪。";
  if (similarity >= 45) return "你们有点互补，也有点互相疑惑，适合边走边吐槽。";
  return "你们路线差异很大，但节目效果很足。";
}

function BuddyReportPage({ playerState, sharedResult, onBack }) {
  const playerType = playerState.personality || "校园迷路型";
  const personalityNames = Object.keys(personalityProfiles);
  const [defaultFriend] = personalityNames.filter((name) => name !== playerType);
  const friendType = sharedResult?.personality || defaultFriend || personalityNames[0];

  return (
    <BuddyReportInner
      playerState={playerState}
      playerType={playerType}
      initialFriendType={friendType}
      sharedResult={sharedResult}
      onBack={onBack}
    />
  );
}

function BuddyReportInner({ playerState, playerType, initialFriendType, sharedResult, onBack }) {
  const [friendType, setFriendType] = useState(initialFriendType);
  const [shareUrl, setShareUrl] = useState("");
  const [shareStatus, setShareStatus] = useState("");
  const profileNames = Object.keys(personalityProfiles);
  const isSharedMatch = Boolean(sharedResult);
  const activeFriendType = sharedResult?.personality || friendType;
  const friendProfile = sharedResult ?? personalityProfiles[friendType];
  const similarity = calculateSimilarity(playerState, friendProfile);
  const report = useMemo(
    () => getBuddyReport(playerType, activeFriendType),
    [playerType, activeFriendType],
  );
  const routeOverlap = getRouteOverlap(playerState, friendProfile);
  const matchTone = getMatchTone(similarity);

  const handleCreateShare = async () => {
    const nextShareUrl = buildShareUrl(playerState);
    setShareUrl(nextShareUrl);
    const isLocalFile = window.location.protocol === "file:";
    const nextStatus = isLocalFile
      ? "本地链接只能在这台电脑测试；上传后生成的链接才能发给朋友。"
      : "链接已复制，发给朋友就能匹配。";

    try {
      await window.navigator.clipboard.writeText(nextShareUrl);
      setShareStatus(nextStatus);
    } catch {
      setShareStatus(isLocalFile ? nextStatus : "链接已生成，可以手动复制。");
    }
  };

  return (
    <section className="screen buddy-screen">
      <header className="buddy-header">
        <button className="icon-button pressable" onClick={onBack} aria-label="返回结算页">←</button>
        <div>
          <h1>你们的外卖搭子报告</h1>
          <p>
            {isSharedMatch
              ? "你和朋友的两份追饭结果已经合并，正在计算搭子相似度。"
              : "先生成一条邀请链接，朋友玩完后就能自动匹配你们的追饭结果。"}
          </p>
        </div>
      </header>

      {!isSharedMatch && (
        <>
          <label className="select-label" htmlFor="friend-type">预览一个朋友人格</label>
          <select id="friend-type" value={friendType} onChange={(event) => setFriendType(event.target.value)}>
            {profileNames.map((name) => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </>
      )}

      <section className="buddy-card">
        <div className="buddy-sparkle" aria-hidden="true">配对中</div>
        <div className="similarity-ring">
          <strong>{similarity}%</strong>
          <span>相似度</span>
        </div>
        <div className="buddy-types">
          <span>你</span>
          <strong>{playerType}</strong>
          <span>{isSharedMatch ? "邀请你的人" : "TA"}</span>
          <strong>{activeFriendType}</strong>
        </div>
      </section>

      <section className="match-detail-grid" aria-label="匹配细节">
        <div>
          <span>共同路线</span>
          <strong>{routeOverlap} 个地点</strong>
        </div>
        <div>
          <span>线索差</span>
          <strong>{Math.abs((playerState.clue ?? 0) - (friendProfile.clue ?? 0))}</strong>
        </div>
        <div>
          <span>脸红差</span>
          <strong>{Math.abs((playerState.socialDeath ?? 0) - (friendProfile.socialDeath ?? 0))}</strong>
        </div>
      </section>

      <section className="report-block">
        <span className="ticket-label">{isSharedMatch ? "真实匹配" : "预览组合"}</span>
        <h2>{report.name}</h2>
        <p className="multiline">{report.comment}</p>
        <p className="multiline">{matchTone}</p>
        <blockquote>{report.shareText}</blockquote>
      </section>

      <div className="rate-grid">
        <div>
          <span>追回率</span>
          <strong>{report.returnRate}</strong>
        </div>
        <div>
          <span>脸红率</span>
          <strong>{report.socialDeathRate}</strong>
        </div>
        <div>
          <span>干饭速度</span>
          <strong>{report.hungerSpeed}</strong>
        </div>
      </div>

      <section className="share-link-panel">
        <button className="primary-button pressable" onClick={handleCreateShare}>
          <span aria-hidden="true">↗</span>
          生成好友匹配链接
        </button>
        {shareStatus && <p>{shareStatus}</p>}
        {shareUrl && <input value={shareUrl} readOnly aria-label="好友匹配分享链接" />}
      </section>

      <button className="secondary-button pressable" onClick={onBack}>
        {isSharedMatch ? "回到我的结算页" : "换一个朋友试试"}
      </button>
    </section>
  );
}

export default BuddyReportPage;
