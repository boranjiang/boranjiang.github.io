export function calculateSimilarity(player, friend) {
  const averageDifference =
    (Math.abs(player.clue - friend.clue) +
      Math.abs(player.socialDeath - friend.socialDeath) +
      Math.abs(player.food - friend.food)) /
    3;

  const statScore = Math.max(0, 100 - averageDifference);
  const playerVisited = player.visited ?? [];
  const friendVisited = friend.visited ?? [];
  const playerChoices = (player.actionHistory ?? []).map((item) => item.choiceId);
  const friendChoices = (friend.actionHistory ?? []).map((item) => item.choiceId);

  const routeScore = friendVisited.length
    ? (playerVisited.filter((item) => friendVisited.includes(item)).length /
        Math.max(playerVisited.length, friendVisited.length, 1)) *
      100
    : statScore;
  const choiceScore = friendChoices.length
    ? (playerChoices.filter((item) => friendChoices.includes(item)).length /
        Math.max(playerChoices.length, friendChoices.length, 1)) *
      100
    : statScore;

  const finalScore = friendVisited.length
    ? statScore * 0.58 + routeScore * 0.27 + choiceScore * 0.15
    : statScore;

  return Math.max(0, Math.min(100, Math.round(finalScore)));
}
