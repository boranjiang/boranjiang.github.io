import {
  buddyTailVariants,
  chatResultVariants,
  endingFlavorVariants,
  locationTextVariants,
} from "../data/textVariants.js";

function pickRandom(items, fallback = null) {
  if (!items?.length) {
    return fallback;
  }

  return items[Math.floor(Math.random() * items.length)];
}

function getPreviousRoute(playerState) {
  return playerState.visited ?? [];
}

function getPreviousLocation(playerState) {
  const route = getPreviousRoute(playerState);
  return route.at(-1) ?? playerState.currentLocation ?? "locker";
}

function hasRecentRoute(playerState, first, second) {
  const route = getPreviousRoute(playerState);
  return route.at(-2) === first && route.at(-1) === second;
}

function getLocationVariantKey(locationId, playerState) {
  const previousLocation = getPreviousLocation(playerState);

  if (locationId === "security" && previousLocation === "gate") {
    return "afterGate";
  }

  if (locationId === "security" && previousLocation === "canteen") {
    return "afterCanteen";
  }

  if (locationId === "gate" && previousLocation === "security") {
    return "afterSecurity";
  }

  if (locationId === "gate" && previousLocation === "canteen") {
    return "afterCanteen";
  }

  if (locationId === "canteen" && previousLocation === "security") {
    return "afterSecurity";
  }

  if (locationId === "canteen" && previousLocation === "gate") {
    return "afterGate";
  }

  if (locationId === "dorm" && hasRecentRoute(playerState, "security", "gate")) {
    return "afterSecurityGate";
  }

  if (locationId === "dorm" && hasRecentRoute(playerState, "gate", "security")) {
    return "afterSecurityGate";
  }

  if (locationId === "dorm" && previousLocation === "security") {
    return "afterSecurity";
  }

  if (locationId === "dorm" && previousLocation === "chat") {
    return "afterChat";
  }

  return "default";
}

export function getContextualLocationEvent(location, playerState) {
  const variants = locationTextVariants[location.id];
  const variantKey = getLocationVariantKey(location.id, playerState);
  const selected =
    pickRandom(variants?.[variantKey]) ??
    pickRandom(variants?.default) ??
    {
      event: location.event,
      feedback: location.feedbackText,
    };

  return {
    ...location,
    event: selected.event,
    feedbackText: selected.feedback ?? location.feedbackText,
  };
}

export function getContextualChatResult(option) {
  const selected = pickRandom(chatResultVariants[option.id], {
    resultText: option.resultText,
    feedbackText: option.feedbackText,
  });

  return {
    ...option,
    resultText: selected.resultText,
    feedbackText: selected.feedbackText,
  };
}

export function enhanceEndingResult(result) {
  const variants = endingFlavorVariants[result.personality];
  const profileText = pickRandom(variants?.profileText, result.profileText);
  const shareText = pickRandom(variants?.shareText, result.shareText);

  return {
    ...result,
    profileText,
    shareText,
  };
}

export function appendBuddyTail(report) {
  const tail = pickRandom(buddyTailVariants, "");

  return {
    ...report,
    comment: tail ? `${report.comment}\n${tail}` : report.comment,
  };
}

// AI API reserved extension point.
// Later, replace this function with a call to your backend or serverless proxy.
// Keep game rules local: AI should only return text fields, never decide score or ending.
export async function generateAIEventText(_context) {
  return null;
}
