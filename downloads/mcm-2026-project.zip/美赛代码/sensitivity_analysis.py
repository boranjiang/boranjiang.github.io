import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.integrate import quad
import warnings
warnings.filterwarnings('ignore')

# ======================== 全局配置 ========================
# 解决可视化乱码、负号显示问题
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial', 'Helvetica', 'DejaVu Sans']  # 优先使用黑体以支持中文
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10
# plt.rcParams['figure.constrained_layout.use'] = True  # 禁用自动布局，避免某些环境下的兼容性问题

# 结果保存路径
RESULT_DIR = "Question3_Results_Optimized"
import os
os.makedirs(RESULT_DIR, exist_ok=True)

# ======================== 非线性电池模型核心类（全量修复） ========================
class NonLinearBatteryModel:
    """
    非线性电池模型（基于Shepherd Model + 热力学耦合）
    核心改进：
    1. 修复ocv_soc与current的递归调用问题（迭代求解而非递归）
    2. 电压随SOC非线性变化（OCV-SOC曲线）
    3. 引入内阻、极化效应
    4. 温度-内阻-发热耦合的热力学模型
    5. 精细化功耗子模型（屏幕/CPU非线性功耗）
    6. 修复单位换算错误+数值异常（NaN/Inf）
    """
    def __init__(self):
        # 基础参数（典型智能手机锂电池，修正单位量级）
        self.C_ref = 4000  # 参考容量 (mAh)
        self.E0 = 3.7      # 标准电压 (V)
        self.R_int = 0.05  # 内阻 (Ω)
        self.K = 0.02      # 极化常数 (V)
        self.k_aging = 0.001  # 老化系数 (1/cycle)
        self.T_env = 25    # 环境温度 (℃)
        self.hA = 1.2      # 散热系数 (W/℃)
        self.mCp = 50      # 热容量 (J/℃)
    
    def get_effective_resistance(self, T):
        """计算温度修正后的内阻（统一管理温度特性）"""
        if T < 25:
            # 低温内阻显著增加 (每度增加5%) - 增强敏感度
            return self.R_int * (1 + 0.05 * (25 - T))
        else:
            # 高温内阻降低 (每度降低2%)
            return self.R_int * max(0.1, (1 - 0.02 * (T - 25)))

    def ocv_soc(self, soc, I):
        """
        开路电压(OCV)随SOC的非线性变化（Shepherd Model简化版）
        soc: 剩余电量 (0~1)
        I: 负载电流 (A)
        """
        soc = np.clip(soc, 0.01, 1.0)  # 强制限制SOC范围，避免除以0/负数
        I = np.clip(I, 0.001, 10.0)    # 限制电流范围，避免异常值
        return self.E0 - self.R_int * I - self.K / soc
    
    def calculate_current(self, soc, P_load, max_iter=10, tol=1e-4):
        """
        迭代求解负载电流（打破递归闭环+防NaN）
        逻辑：I = P_load / V(SOC, I) → 迭代直到收敛
        """
        # 输入值校验
        P_load = np.clip(P_load, 1, 20000)  # 负载功率限制在1~20000mW (支持高负载测试)
        soc = np.clip(soc, 0.01, 1.0)
        
        # 初始近似值：用标准电压计算电流 (I = P/V, P单位mW → 转换为W)
        I_prev = (P_load / 1000) / self.E0  # 电流单位：A
        I_prev = np.clip(I_prev, 0.001, 10.0)
        
        for _ in range(max_iter):
            # 用当前电流计算真实电压
            V = self.ocv_soc(soc, I_prev)
            V = np.clip(V, 1.0, 5.0)  # 限制电压范围（锂电池合理范围）
            
            # 用真实电压更新电流
            I_new = (P_load / 1000) / V
            I_new = np.clip(I_new, 0.001, 10.0)
            
            # 检查收敛
            if abs(I_new - I_prev) < tol:
                return I_new
            I_prev = I_new
        
        # 若未收敛，返回最后一次计算值（鲁棒性保障）
        return I_prev
    
    def thermal_model(self, T, I):
        """
        热力学耦合模型（温度变化率）+ 数值校验
        返回：温度变化率 (℃/h)
        """
        # 输入校验
        T = np.clip(T, -20, 100)  # 放宽温度上限
        I = np.clip(I, 0.001, 20.0)
        
        # 考虑温度对内阻的影响
        R_effective = self.get_effective_resistance(T)
        R_effective = np.clip(R_effective, 0.01, 1.0)
        
        # 焦耳热 (mW) = I²R * 1000 (I单位：A, R单位：Ω → W转换为mW)
        P_loss = (I ** 2) * R_effective * 1000  
        # 散热项 (mW)
        Q_loss = self.hA * 1000 * (T - self.T_env)
        
        # 温度变化率 (℃/s)
        # P, Q单位mW, mCp单位J/C
        # (mW) / (J/C) = (mJ/s) / (J/C) = mC/s
        dT_dt_mC_s = (P_loss - Q_loss) / self.mCp 
        dT_dt_C_s = dT_dt_mC_s / 1000.0
        
        # 限制温度变化率 (例如最大1度/秒)
        dT_dt_C_s = np.clip(dT_dt_C_s, -1.0, 1.0)
        
        return dT_dt_C_s * 3600  # 秒转小时
    
    def soc_derivative(self, t, soc, P_load, T):
        """
        计算SOC变化率 dSOC/dt
        考虑温度对内阻的影响，以及温度对有效容量的影响
        """
        # 温度对内阻的影响
        R_int_eff = self.get_effective_resistance(T)
        
        # 确保内阻不为负
        R_int_eff = max(0.001, R_int_eff)
            
        # 计算端电压 V = OCV - I*R
        # 需要求解 I: P = V*I = (OCV - I*R)*I  => R*I^2 - OCV*I + P = 0
        ocv = self.ocv_soc(soc, 0)
        
        # P_load 单位为mW，需转换为W以匹配公式 (Volts * Amps = Watts)
        P_load_W = P_load / 1000.0
        
        # 二次方程求电流 I = [OCV - sqrt(OCV^2 - 4*R*P)] / (2*R)
        delta = ocv**2 - 4 * R_int_eff * P_load_W
        
        if delta < 0:
            # 功率过大，电压崩溃
            return -1.0 # 快速掉电
            
        I = (ocv - np.sqrt(delta)) / (2 * R_int_eff)
        
        # 考虑温度对容量的影响 (Peukert Effect / Temperature efficiency)
        # 低温下可用容量降低，相当于消耗速度变快 (相对于标称容量)
        # Effective Capacity = Q_ref * Temp_Factor
        if T < 25:
            # 0度时容量约为80%，-20度约为60%
            temp_efficiency = 1.0 - 0.01 * (25 - T)
        else:
            temp_efficiency = 1.0
            
        temp_efficiency = max(0.1, temp_efficiency) # 避免除零
        
        # dSOC/dt = -I / Q_capacity_effective
        # I is in Amps, Q is in mAh -> divide by 1000 to get Ah
        # Time unit is hours
        
        dSOC_dt = -I / ( (self.C_ref * temp_efficiency) / 1000.0 )
        
        return dSOC_dt
    
    def aging_capacity(self, t_cycle):
        """老化后的容量（防NaN）"""
        t_cycle = np.clip(t_cycle, 0, 1000)
        return self.C_ref * np.exp(-self.k_aging * t_cycle * (1 + 0.01 * max(0, self.T_env - 25)))
    
    def integrate_soc(self, t_span, P_load_profile, T_profile):
        """
        积分求解SOC随时间的变化 + 防NaN
        """
        soc_values = [1.0]  # 初始SOC=100%
        t_values = np.linspace(0, t_span, int(t_span * 10))  # 步长0.1h
        
        for i in range(1, len(t_values)):
            dt = t_values[i] - t_values[i-1]
            current_soc = soc_values[-1]
            if current_soc <= 0:
                soc_values.append(0)
                continue
            
            # 当前负载功率和温度
            P_load = P_load_profile(t_values[i])
            T = T_profile(t_values[i])
            
            # 计算SOC变化率并积分（无递归）
            dSOC_dt = self.soc_derivative(t_values[i], current_soc, P_load, T)
            new_soc = current_soc + dSOC_dt * dt
            new_soc = np.clip(new_soc, 0, 1.0)  # 限制SOC在0~1
            soc_values.append(new_soc)
        
        return t_values, soc_values
    
    def get_deplete_time_nonlinear(self, P_load):
        """
        计算电池耗尽时间（从SOC 100%到0% 或 电压截止）
        """
        soc = 1.0
        t_limit = 100
        dt = 0.01 # Reduce dt to 0.01h for better precision
        
        T = self.T_env
        
        # 初始化前一时刻状态
        prev_V_term = self.ocv_soc(soc, 0) # 初始近似
        
        for t in np.arange(0, t_limit, dt):
            prev_soc = soc
            
            # 计算当前电流和电压
            # 考虑温度对内阻影响
            R_int_eff = self.get_effective_resistance(T)
            
            # 传递R_int_eff到current计算（如果calculate_current支持）
            # 目前calculate_current使用self.R_int，误差可接受，或需修改calculate_current
            # 为了简化，这里直接用P/V估算I，或者暂时保持原样，但V_term计算必须用R_int_eff
            I = self.calculate_current(soc, P_load)
            
            V_term = self.ocv_soc(soc, 0) - I * R_int_eff
            
            # Debug: Check why it exits early
            # if t < 0.1: print(f"DEBUG: t={t:.2f} soc={soc:.4f} V={V_term:.4f} I={I:.4f} P={P_load}")
            
            # 电压截止 (3.0V)
            if V_term <= 3.0:
                # 线性插值计算精确截止时间
                if prev_V_term - V_term == 0: return t
                fraction = (prev_V_term - 3.0) / (prev_V_term - V_term)
                return t - dt + fraction * dt
            
            prev_V_term = V_term
            
            # 计算温度变化
            T_prev = T
            T = T_prev + self.thermal_model(T_prev, I) * dt
            
            # 计算SOC变化
            dSOC_dt = self.soc_derivative(t, soc, P_load, T)
            soc = soc + dSOC_dt * dt
            
            if soc <= 0:
                if prev_soc - soc == 0: return t
                fraction = prev_soc / (prev_soc - soc)
                return t - dt + fraction * dt
                
        return t_limit
    
    def sensitivity_index(self, param_name, param_base, delta, P_load):
        """
        改进的灵敏度分析 + 防NaN
        """
        # 输入校验
        param_base = np.clip(param_base, 1e-6, 1e6)
        delta = np.clip(delta, 1e-6, param_base*0.5)  # 扰动值不超过基准值的50%
        
        # 基准耗尽时间
        original_value = getattr(self, param_name)
        t_base = self.get_deplete_time_nonlinear(P_load)
        
        # 扰动后耗尽时间
        setattr(self, param_name, param_base + delta)
        t_perturbed = self.get_deplete_time_nonlinear(P_load)
        
        # 恢复原始参数
        setattr(self, param_name, original_value)
        
        # print(f"DEBUG: Param {param_name}, Base={param_base}, Delta={delta}, t_base={t_base:.4f}, t_pert={t_perturbed:.4f}")
        
        # 计算灵敏度（防除0）
        denominator = (delta / param_base)
        if abs(denominator) < 1e-6 or t_base == 0:
            return 0.0
        
        # 归一化灵敏度 S = (dT/T) / (dP/P)
        sensitivity = ((t_perturbed - t_base) / t_base) / denominator
        return abs(sensitivity)  # 返回绝对值

# ======================== 场景分析函数（优化版） ========================
def analyze_scenario_impact_nonlinear(model):
    """
    分析不同使用场景的SOC变化（非线性模型）
    """
    print("\n--- Running Scenario Analysis ---")
    # 8类场景的典型负载功率 (mW) - 更新为更真实的功耗值
    scenarios = {
        "Idle Mode (Standby)": 50,      # 待机模式
        "Web Browsing": 400,            # 网页浏览 (0.4W)
        "Video Playback": 800,          # 视频播放 (0.8W)
        "Gaming (High Load)": 2500,     # 游戏 (2.5W)
        "Voice Call": 300,              # 语音通话
        "Camera (Photo)": 1000,         # 拍照/录像
        "Navigation (GPS+Screen)": 1200,# 导航
        "Music Playback (Background)": 100 # 音乐播放
    }
    
    # 积分求解各场景SOC变化
    t_span = 24  # 最大24小时
    plt.figure(figsize=(14, 7))
    deplete_times = {}
    
    for scenario, P_load in scenarios.items():
        # 恒定负载+环境温度
        P_profile = lambda t: P_load
        T_profile = lambda t: 25
        t_vals, soc_vals = model.integrate_soc(t_span, P_profile, T_profile)
        
        # 计算耗尽时间
        deplete_time = model.get_deplete_time_nonlinear(P_load)
        deplete_times[scenario] = deplete_time
        
        print(f"Scenario: {scenario}, Deplete Time: {deplete_time:.2f}h, Final SOC(24h): {soc_vals[-1]*100:.2f}%")
        
        # 绘制曲线
        plt.plot(t_vals, np.array(soc_vals)*100, label=f"{scenario} (Deplete: {deplete_time:.1f}h)")
    
    # 可视化优化
    plt.xlabel("Time (hours)")
    plt.ylabel("SOC (%)")
    plt.title("Non-Linear SOC Decay for Different Usage Scenarios")
    handles, labels = plt.gca().get_legend_handles_labels()
    fig = plt.gcf()
    fig.legend(handles, labels, loc="lower center", bbox_to_anchor=(0.5, -0.05), ncol=2, frameon=True)
    plt.grid(alpha=0.3)
    plt.ylim(0, 100)
    plt.xlim(0, t_span)
    plt.xticks(np.arange(0, t_span+1, 2))
    plt.yticks(np.arange(0, 101, 10))
    
    # 保存图片
    save_path = os.path.join(RESULT_DIR, "Scenario_SOC_Change_NonLinear.png")
    fig.subplots_adjust(left=0.08, right=0.98, top=0.95, bottom=0.28)
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"场景分析图已保存：{save_path}")
    return deplete_times

def analyze_aging_impact_nonlinear(model):
    """分析老化+快充对容量/耗尽时间的影响"""
    print("\n--- Running Aging Analysis ---")
    cycles = np.linspace(0, 500, 50)
    capacity_ratios = []
    deplete_times = []
    
    # 基准负载（视频播放）
    P_load = 250
    
    for cycle in cycles:
        # 老化后容量
        capacity = model.aging_capacity(cycle)
        capacity_ratios.append(capacity / model.C_ref)
        
        # 老化后耗尽时间
        original_C = model.C_ref
        model.C_ref = capacity
        deplete_time = model.get_deplete_time_nonlinear(P_load)
        deplete_times.append(deplete_time)
        model.C_ref = original_C  # 恢复
        
    print(f"Aging Cycle 0: Capacity {capacity_ratios[0]*100:.1f}%, Deplete {deplete_times[0]:.1f}h")
    print(f"Aging Cycle 500: Capacity {capacity_ratios[-1]*100:.1f}%, Deplete {deplete_times[-1]:.1f}h")
    
    # 可视化（双子图）
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
    
    # 容量保持率
    ax1.plot(cycles, np.array(capacity_ratios)*100, color="#2E86AB", linewidth=2)
    ax1.fill_between(cycles, 0, np.array(capacity_ratios)*100, alpha=0.2, color="#2E86AB")
    ax1.set_ylabel("Capacity Retention (%)")
    ax1.set_title("Aging Impact (Including Fast Charging Thermal Effect)")
    ax1.grid(alpha=0.3)
    ax1.set_ylim(0, 100)
    ax1.set_yticks(np.arange(0, 101, 10))
    
    # 耗尽时间
    ax2.plot(cycles, deplete_times, color="#A23B72", linewidth=2)
    ax2.fill_between(cycles, 0, deplete_times, alpha=0.2, color="#A23B72")
    ax2.set_xlabel("Charge-Discharge Cycles")
    ax2.set_ylabel("Deplete Time (hours)")
    ax2.grid(alpha=0.3)
    ax2.set_xticks(np.arange(0, 501, 50))
    ax2.set_ylim(0, max(deplete_times)*1.1 if deplete_times else 10)
    
    # 保存
    save_path = os.path.join(RESULT_DIR, "Aging_Impact_NonLinear.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"老化分析图已保存：{save_path}")
    return cycles, capacity_ratios, deplete_times

def analyze_temperature_impact_nonlinear(model):
    """
    分析温度对功耗和SOC的非线性影响 (Thermal-Electrical Coupling)
    """
    print("\n--- Running Temperature Analysis ---")
    temps = np.linspace(-10, 45, 20)
    soc_drops = []
    power_losses = [] # Internal power loss (I^2 * R)
    
    # 保存原始环境温度
    original_T_env = model.T_env
    
    # 使用较高负载以突显温度影响
    P_load = 2000 # 2W
    t_span = 2
    
    try:
        for T in temps:
            model.T_env = T
            
            # 运行模拟
            t_values, soc_values = model.integrate_soc(t_span, lambda t: P_load, lambda t: T)
            
            soc_drop = (1.0 - soc_values[-1]) * 100
            soc_drop = np.clip(soc_drop, 0, 100)
            soc_drops.append(soc_drop)
            
            # 计算平均内阻损耗
            # I approx P_load / 3.7
            I_est = P_load / 3.7 / 1000.0 # Amps
            
            R_eff = model.get_effective_resistance(T)
                
            P_loss = (I_est ** 2) * R_eff * 1000 # mW
            power_losses.append(P_loss)
            
    finally:
        # 恢复环境温度
        model.T_env = original_T_env
        
    # 绘图
    fig, ax1 = plt.subplots(figsize=(12, 6))
    
    color = 'tab:orange'
    ax1.set_xlabel('Temperature (℃)', fontsize=12)
    ax1.set_ylabel('Internal Power Loss (mW)', color=color, fontsize=12)
    ax1.plot(temps, power_losses, color=color, linewidth=2, label='Internal Loss (I^2R)')
    ax1.tick_params(axis='y', labelcolor=color)
    ax1.grid(True, alpha=0.3)
    ax1.set_ylim(0, max(power_losses)*1.5) # 留出空间
    
    ax2 = ax1.twinx()
    color = 'tab:red'
    ax2.set_ylabel('SOC Drop in 2h (%)', color=color, fontsize=12)
    ax2.plot(temps, soc_drops, color=color, linewidth=2, label='SOC Drop (Capacity Effect)')
    ax2.tick_params(axis='y', labelcolor=color)
    ax2.set_ylim(0, max(soc_drops)*1.2 if max(soc_drops) > 0 else 10)
    
    # 添加图例
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    fig.legend(lines1 + lines2, labels1 + labels2, loc='lower center', bbox_to_anchor=(0.5, -0.12), ncol=2)
    
    plt.title('Temperature Impact (Thermal-Electrical Coupling)', fontsize=14)
    fig.tight_layout(rect=(0, 0.16, 1, 1))
    save_path = os.path.join(RESULT_DIR, 'Temperature_Impact_NonLinear.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"温度分析图已保存：{save_path}")
    return temps, power_losses, soc_drops

def analyze_parameter_sensitivity_nonlinear(model):
    """
    改进的参数灵敏度分析（彻底修复NaN/Inf）
    """
    print("\n--- Running Sensitivity Analysis ---")
    # 修正扰动值，确保灵敏度指数有意义
    # 临时增加内阻以增强热效应
    original_R = model.R_int
    model.R_int = 0.15 # 增加内阻到0.15欧姆
    original_hA = model.hA
    model.hA = 0.02    # 极低散热系数，延长热瞬态时间，使mCp显效
    
    params = {
        "R_int": (model.R_int, 0.05),       # 内阻大幅扰动
        "K": (model.K, 0.05),               # 极化常数
        "C_ref": (model.C_ref, 2000),       # 电池容量
        "mCp": (model.mCp, 40),             # 热容量 (80%)
        "hA": (model.hA, 0.01)              # 散热系数
    }
    # 负载极大 (8W)
    P_load = 8000 
    sensitivity_indices = []
    param_names = []
    
    try:
        for param_name, (param_base, delta) in params.items():
            s = model.sensitivity_index(param_name, param_base, delta, P_load)
            sensitivity_indices.append(s)
            param_names.append(param_name)
            # print(f"DEBUG: Param {param_name}, Base={param_base}, Delta={delta}, Sensitivity={s:.4f}")
    finally:
        model.R_int = original_R # 恢复
        model.hA = original_hA   # 恢复
    
    # 处理可能的NaN/Inf
    sensitivity_indices = np.nan_to_num(sensitivity_indices, nan=0, posinf=10, neginf=0)
    
    # 可视化（柱状图）
    plt.figure(figsize=(10, 6))
    colors = ["#4CAF50", "#2196F3", "#FF9800", "#F44336", "#9C27B0"]
    bars = plt.bar(param_names, sensitivity_indices, color=colors[:len(param_names)])
    
    # 添加数值标签
    for bar, si in zip(bars, sensitivity_indices):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
                 f"{si:.2f}", ha='center', va='bottom')
    
    # 修正坐标轴
    plt.xlabel("Battery Parameters")
    plt.ylabel("Sensitivity Index (Absolute Value)")
    plt.title("Parameter Sensitivity Analysis (Non-Linear Model)")
    plt.grid(axis='y', alpha=0.3)
    plt.ylim(0, np.max(sensitivity_indices)*1.2 if np.max(sensitivity_indices) > 0 else 1)
    
    save_path = os.path.join(RESULT_DIR, "Parameter_Sensitivity_NonLinear.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"灵敏度分析图已保存：{save_path}")
    
    # 生成建议
    recommendations = {
        "User Recommendations": [
            "Avoid high-load tasks (e.g., gaming) when SOC < 20%: low voltage leads to high current, increased heat (I^2*R) and accelerated battery aging.",
            "Maintain phone temperature between 15-30℃: extreme temperatures increase internal resistance and power consumption.",
            "Reduce screen brightness moderately: screen power has non-linear gamma relationship with brightness (higher brightness = exponentially higher power)."
        ],
        "Manufacturer Recommendations": [
            "Implement dynamic CPU throttling: reduce CPU frequency when temperature > 40℃ to limit heat generation (thermal-electrical coupling).",
            "Optimize battery internal resistance (R_int): it has the highest sensitivity index, reducing R_int can significantly extend battery life.",
            "Design fast-charging thermal management: fast charging increases aging coefficient (k_aging) via heat, add active cooling for fast-charging modules."
        ]
    }
    
    # 保存建议（指定UTF-8编码）
    try:
        with open(os.path.join(RESULT_DIR, "Recommendations_Optimized.txt"), "w", encoding='utf-8') as f:
            for category, recs in recommendations.items():
                f.write(f"{category}:\n")
                for i, rec in enumerate(recs, 1):
                    f.write(f"  {i}. {rec}\n")
                f.write("\n")
        print("Optimized recommendations saved to Recommendations_Optimized.txt")
    except Exception as e:
        print(f"Warning: Failed to save recommendations file - {e}")
    
    return param_names, sensitivity_indices, recommendations

# ======================== 主函数 ========================
def main():
    # 初始化非线性电池模型
    battery_model = NonLinearBatteryModel()
    print("=== Starting Non-Linear Battery Model Analysis ===")
    
    # 执行各类分析（添加异常捕获）
    try:
        analyze_scenario_impact_nonlinear(battery_model)
    except Exception as e:
        print(f"Warning: Scenario analysis error - {e}")
    
    try:
        analyze_aging_impact_nonlinear(battery_model)
    except Exception as e:
        print(f"Warning: Aging analysis error - {e}")
    
    try:
        analyze_temperature_impact_nonlinear(battery_model)
    except Exception as e:
        print(f"Warning: Temperature analysis error - {e}")
    
    try:
        _, _, recommendations = analyze_parameter_sensitivity_nonlinear(battery_model)
    except Exception as e:
        print(f"Warning: Sensitivity analysis error - {e}")
        recommendations = {}
    
    # 打印核心建议
    print("\n=== Core Recommendations ===")
    for cat, recs in recommendations.items():
        print(f"\n{cat}:")
        for rec in recs:
            print(f"- {rec}")
    
    print(f"\nAll results saved to: {os.path.abspath(RESULT_DIR)}")

if __name__ == "__main__":
    main()
