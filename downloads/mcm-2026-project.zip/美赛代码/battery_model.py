import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import os
import sys
import pandas as pd
from typing import Dict, List, Tuple, Optional

# ===================== 核心配置 =====================
class Config:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__)) if __file__ else os.getcwd()
    SAVE_DIR = os.path.join(os.path.dirname(CURRENT_DIR), "Battery_Analysis_Results")
    CSV_FILE = os.path.join(CURRENT_DIR, "不同使用场景下的电池电量变化.csv")
    
    PLOT_FONT = {
        'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
        'axes.unicode_minus': False,
        'font.size': 8,
        'figure.dpi': 300,
        'savefig.dpi': 300
    }
    
    CORE_USAGE_LEVELS = {
        '待机': 'Standby',
        '轻度使用': 'Light Usage',
        '中度使用': 'Medium Usage',
        '重度使用': 'Heavy Usage'
    }
    
    USAGE_LEVEL_POWER = {
        '待机': {'screen': 'off', 'cpu': 'idle', 'network': 'off', 'gps': 'off'},
        '轻度使用': {'screen': 'low', 'cpu': 'low', 'network': 'wifi', 'gps': 'off'},
        '中度使用': {'screen': 'medium', 'cpu': 'medium', 'network': '4g', 'gps': 'on'},
        '重度使用': {'screen': 'high', 'cpu': 'high', 'network': '5g', 'gps': 'on'}
    }
    
    TEST_TEMPERATURES = [-10, 0, 25, 40]
    TEST_AGING_LEVELS = [0.0, 0.1, 0.2, 0.3]

# ===================== 文件工具类 =====================
class FileUtils:
    @staticmethod
    def create_dir(dir_path: str) -> bool:
        try:
            os.makedirs(dir_path, exist_ok=True)
            print(f"✅ 目录创建成功: {dir_path}")
            return True
        except Exception as e:
            print(f"❌ 目录创建失败: {e}")
            return False
    
    @staticmethod
    def load_battery_params(file_path: str) -> Optional[dict]:
        if not os.path.exists(file_path):
            print(f"❌ CSV文件不存在: {file_path}")
            return None
        
        try:
            df = pd.read_csv(file_path, encoding='utf-8')
        except:
            df = pd.read_csv(file_path, encoding='gbk')
        
        params = {
            'battery_capacity': df['battery_capacity'].iloc[0] if 'battery_capacity' in df.columns else 5000,
            'base_temperature': df['temperature'].iloc[0] if 'temperature' in df.columns else 25,
            'base_aging': df['aging_level'].iloc[0] if 'aging_level' in df.columns else 0.0
        }
        print(f"✅ 加载电池参数: 容量={params['battery_capacity']}mAh, 基准温度={params['base_temperature']}°C")
        return params

# ===================== 电池模型 =====================
class BatteryModel:
    def __init__(self, capacity: float, aging_level: float = 0.0):
        self.capacity = capacity * (1 - aging_level)
        self.initial_soc = 100.0
        self.temp_factor = 1.0
        
        self.component_power = {
            'screen': {'off': 0, 'low': 150, 'medium': 300, 'high': 500},
            'cpu': {'idle': 50, 'low': 100, 'medium': 200, 'high': 400},
            'network': {'off': 0, 'wifi': 80, '4g': 150, '5g': 250},
            'gps': {'off': 0, 'on': 100}
        }

    def update_temp_factor(self, temperature: float) -> None:
        if temperature < 0:
            self.temp_factor = 0.8
        elif temperature > 35:
            self.temp_factor = 1.2
        else:
            self.temp_factor = 1.0

    def calculate_power(self, usage_level: str, temperature: float = 25) -> float:
        self.update_temp_factor(temperature)
        params = Config.USAGE_LEVEL_POWER.get(usage_level, Config.USAGE_LEVEL_POWER['待机'])
        
        total_power = (
            50 +
            self.component_power['screen'][params['screen']] +
            self.component_power['cpu'][params['cpu']] +
            self.component_power['network'][params['network']] +
            self.component_power['gps'][params['gps']] +
            100
        ) * self.temp_factor
        
        return total_power

    def simulate_soc(self, duration: float, usage_level: str, temperature: float = 25) -> Tuple[np.ndarray, np.ndarray]:
        power = self.calculate_power(usage_level, temperature)
        
        sol = solve_ivp(
            fun=lambda t, soc: - (power / self.capacity) * 100,
            t_span=(0, duration),
            y0=[self.initial_soc],
            method='RK45',
            t_eval=np.linspace(0, duration, 100)
        )
        return sol.t, sol.y[0]

    def get_power_breakdown(self, usage_level: str, temperature: float = 25) -> List[float]:
        self.update_temp_factor(temperature)
        params = Config.USAGE_LEVEL_POWER.get(usage_level, Config.USAGE_LEVEL_POWER['待机'])
        
        breakdown = [
            50 * self.temp_factor,
            self.component_power['screen'][params['screen']] * self.temp_factor,
            self.component_power['cpu'][params['cpu']] * self.temp_factor,
            self.component_power['network'][params['network']] * self.temp_factor,
            self.component_power['gps'][params['gps']] * self.temp_factor,
            100 * self.temp_factor
        ]
        return breakdown

# ===================== 可视化类（高对比度配色） =====================
class BatteryVisualizer:
    def __init__(self, model: BatteryModel, base_params: dict):
        plt.rcParams.update(Config.PLOT_FONT)
        self.model = model
        self.base_params = base_params
        self.save_dir = Config.SAVE_DIR
        FileUtils.create_dir(self.save_dir)
        # 核心优化：Screen改为高对比度橙红色(#ff4500)，其余颜色保持协调
        self.component_colors = ['#8dd3c7', '#ff4500', '#bebada', '#fb8072', '#80b1d3', '#fdb462']
        self.power_components = ['Baseline', 'Screen', 'CPU', 'Network', 'GPS', 'Background']
        self.colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
        self.linestyles = ['-', '--', '-.', ':']

    def plot_soc_by_usage_level(self) -> None:
        fig, ax = plt.subplots(figsize=(10, 6))
        
        for idx, (cn_level, en_level) in enumerate(Config.CORE_USAGE_LEVELS.items()):
            t, soc = self.model.simulate_soc(12, cn_level, self.base_params['base_temperature'])
            ax.plot(t, soc, label=en_level, color=self.colors[idx], linewidth=2.5)
        
        ax.set_title('Battery SOC Decay for Different Usage Levels', fontsize=12, fontweight='bold')
        ax.set_xlabel('Usage Time (Hours)', fontsize=10, fontweight='bold')
        ax.set_ylabel('Remaining SOC (%)', fontsize=10, fontweight='bold')
        ax.set_ylim(0, 105)
        ax.legend(fontsize=8, loc='center right', bbox_to_anchor=(1.25, 0.5))
        ax.grid(alpha=0.5, linestyle='-', linewidth=0.8)
        
        self._save_fig(fig, '1_SOC_Decay_by_Usage_Level.png')
        plt.close(fig)

    def plot_power_comparison(self) -> None:
        fig, ax = plt.subplots(figsize=(8, 6))
        usage_levels_en = list(Config.CORE_USAGE_LEVELS.values())
        power_values = []
        
        for cn_level in Config.CORE_USAGE_LEVELS.keys():
            power = self.model.calculate_power(cn_level, self.base_params['base_temperature'])
            power_values.append(power)
        
        bars = ax.bar(usage_levels_en, power_values, color=self.colors, width=0.6)
        
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 10,
                    f'{height:.0f} mW', ha='center', va='bottom', fontsize=8, fontweight='bold')
        
        ax.set_title('Power Consumption Comparison by Usage Level', fontsize=12, fontweight='bold')
        ax.set_xlabel('Usage Level', fontsize=10, fontweight='bold')
        ax.set_ylabel('Power Consumption (mW)', fontsize=10, fontweight='bold')
        ax.tick_params(axis='x', labelsize=8)
        ax.grid(axis='y', alpha=0.3)
        
        self._save_fig(fig, '2_Power_Consumption_Comparison.png')
        plt.close(fig)

    def plot_temperature_impact(self) -> None:
        fig, ax = plt.subplots(figsize=(14, 8))
        
        for level_idx, (cn_level, en_level) in enumerate(Config.CORE_USAGE_LEVELS.items()):
            for temp_idx, temp in enumerate(Config.TEST_TEMPERATURES):
                t, soc = self.model.simulate_soc(10, cn_level, temp)
                ax.plot(t, soc, 
                        label=f'{en_level} ({temp}°C)',
                        color=self.colors[level_idx],
                        linestyle=self.linestyles[temp_idx],
                        linewidth=1.8)
        
        ax.set_title('Temperature Impact on SOC for All Usage Levels', fontsize=12, fontweight='bold')
        ax.set_xlabel('Usage Time (Hours)', fontsize=10, fontweight='bold')
        ax.set_ylabel('Remaining SOC (%)', fontsize=10, fontweight='bold')
        ax.set_ylim(0, 105)
        ax.legend(fontsize=7, loc='upper right', ncol=2, bbox_to_anchor=(1.0, 1.0))
        ax.grid(alpha=0.5)
        
        self._save_fig(fig, '3_Temperature_Impact_on_SOC.png')
        plt.close(fig)

    def plot_aging_impact(self) -> None:
        fig, ax = plt.subplots(figsize=(14, 8))
        base_capacity = self.base_params['battery_capacity']
        
        for level_idx, (cn_level, en_level) in enumerate(Config.CORE_USAGE_LEVELS.items()):
            for aging_idx, aging in enumerate(Config.TEST_AGING_LEVELS):
                temp_model = BatteryModel(base_capacity, aging)
                t, soc = temp_model.simulate_soc(10, cn_level, self.base_params['base_temperature'])
                
                ax.plot(t, soc, 
                        label=f'{en_level} ({aging*100}% Aging)',
                        color=self.colors[level_idx],
                        linestyle=self.linestyles[aging_idx],
                        linewidth=1.8)
        
        ax.set_title('Aging Impact on SOC for All Usage Levels', fontsize=12, fontweight='bold')
        ax.set_xlabel('Usage Time (Hours)', fontsize=10, fontweight='bold')
        ax.set_ylabel('Remaining SOC (%)', fontsize=10, fontweight='bold')
        ax.set_ylim(0, 105)
        # 图例优化：分4列显示，紧贴右上角，不超出图表范围
        ax.legend(fontsize=7, loc='upper right', ncol=4, bbox_to_anchor=(1.0, 1.0))
        ax.grid(alpha=0.5)
        
        self._save_fig(fig, '4_Aging_Impact_on_SOC.png')
        plt.close(fig)

    def plot_power_breakdown(self) -> None:
        fig, axes = plt.subplots(2, 2, figsize=(14, 12))
        axes = axes.flatten()
        fig.suptitle('Power Consumption Breakdown by Usage Level', fontsize=14, fontweight='bold', y=0.98)
        
        for idx, (cn_level, en_level) in enumerate(Config.CORE_USAGE_LEVELS.items()):
            breakdown = self.model.get_power_breakdown(cn_level, self.base_params['base_temperature'])
            
            wedges, texts, autotexts = axes[idx].pie(
                breakdown, startangle=90, autopct='%1.1f%%', 
                colors=self.component_colors,
                wedgeprops=dict(width=0.7), pctdistance=0.75,
                textprops={'fontsize': 7, 'fontweight': 'bold', 'color': 'white'}
            )
            
            axes[idx].set_title(f'{en_level}', fontsize=10, fontweight='bold')
        
        fig.legend(wedges, self.power_components, 
                  loc='lower center', ncol=6, fontsize=8, 
                  bbox_to_anchor=(0.5, 0.02))
        
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])
        self._save_fig(fig, '5_Power_Consumption_Breakdown.png')
        plt.close(fig)

    def _save_fig(self, fig: plt.Figure, filename: str) -> None:
        save_path = os.path.join(self.save_dir, filename)
        try:
            fig.savefig(save_path, bbox_inches='tight', pad_inches=0.2)
            print(f"✅ 图表保存成功: {filename}")
        except Exception as e:
            print(f"❌ 图表保存失败 {filename}: {e}")

# ===================== 主程序入口 =====================
def main():
    print("=" * 80)
    print("📊 电池性能整体分析程序（高对比度配色最终版）")
    print("=" * 80)
    
    base_params = FileUtils.load_battery_params(Config.CSV_FILE)
    if not base_params:
        return
    
    battery_model = BatteryModel(base_params['battery_capacity'], base_params['base_aging'])
    visualizer = BatteryVisualizer(battery_model, base_params)
    
    print("\n🚀 开始生成最终优化图表...")
    visualizer.plot_soc_by_usage_level()
    visualizer.plot_power_comparison()
    visualizer.plot_temperature_impact()
    visualizer.plot_aging_impact()
    visualizer.plot_power_breakdown()
    
    print("\n🎉 所有图表生成完成！")
    print(f"📁 图表保存路径: {Config.SAVE_DIR}")
    print("\n📋 生成的图表清单：")
    print("  1. 1_SOC_Decay_by_Usage_Level.png   - SOC衰减对比")
    print("  2. 2_Power_Consumption_Comparison.png - 功耗对比")
    print("  3. 3_Temperature_Impact_on_SOC.png - 温度影响分析")
    print("  4. 4_Aging_Impact_on_SOC.png       - 老化影响分析（图例优化）")
    print("  5. 5_Power_Consumption_Breakdown.png - 功耗构成（高对比度配色）")

if __name__ == '__main__':
    main()